<?php include('files/header.php'); ?>

<style type="text/css">
	body{
	background: #2f3640;
}
</style>

<div class="container">
<div class="row">

	<div class="col-md-6 col-md-offset-3">
<div class="loginf">
		<h4>Confirm OTP Code to reset your password !</h4>
		<br>
		<label>Enter OTP code send to your register mobile / email  <span>*</span></label>

		<form action="" method="">
			<input type="text" class="form-control" name="uid" id="uid" placeholder="eg : 872393">
			<button class="btn" type="submit" name="submit" id="submit">Submit OTP code</button>
		</form>
		<br>
		<a href="">OTP not recived Resend again ?</a>

	</div>	
	
</div>
</div>
</div>



</body>
</html>