<?php 

if(isset($_GET['order'])){

	$orderid = $_GET['order'];
	$userid = $_GET['user'];		


require('fpdf/fpdf.php');

$pdf = new FPDF();
$pdf->AddPage();

	include("code/connect.php");
	include("code/getdetails.php");

	$fetcship = "select * from address where userid='$userid'";
	$npss = mysqli_query($con,$fetcship);

	while ($nise  = mysqli_fetch_array($npss)) {
		$shipid = $nise['id'];
		$name = $nise['name'];
		$email = $nise['email'];
		$mobile = $nise['mobile'];
		$address = $nise['address'];
		$landmark = $nise['landmark'];
}


@$fetc = "select * from orders where userid='$userid' && order_id='$orderid'";
$nps = mysqli_query($con,$fetc);
while ($nis  = mysqli_fetch_array($nps)) {
$orderdate = $nis['date'];
$delivery_date = $nis['delevery_date'];
$delivery_slot = $nis['delivery_slot'];
}

$pdf->Ln(8);
$pdf->SetFont('Arial','',25);
$pdf->Cell(0,0,'INVOICE',0,1,"R");

// $pdf->Ln(0);
// $pdf->SetFont('Arial','',10);
// $pdf->Cell(0,15,'#0000034',0,0,"R");

$pdf->Ln(0);
$pdf->SetFont('Arial','',10);
$pdf->Cell(165,45,'Order ID : ',0,0,"R");
$pdf->SetFont('Arial','',10);
$pdf->Cell(0,45,"#{$orderid}",0,0,"R");

$pdf->Ln(7);
$pdf->SetFont('Arial','',10);
$pdf->Cell(165,45,'Order Date : ',0,0,"R");
$pdf->SetFont('Arial','',10);
$pdf->Cell(0,45,"{$orderdate}",0,0,"R");


$pdf->Ln(0);
$pdf->Image('images/moblogo.png',10,10,-300);

$pdf->Ln(-5);
$pdf->SetFont('Arial','',10);
$pdf->Cell(0,17,'Groceries | Food | Vegetable | Meat | Fruites | Dairy',0,1);

$pdf->Ln(5);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(0,0,'Address',0,1);


$pdf->Ln(0);
$pdf->SetFont('Arial','',8);
$pdf->Cell(0,10,'#9-24/1 Mukrampura Opp NoorPlaza Complex',0,0);

$pdf->Ln(0);
$pdf->SetFont('Arial','',8);
$pdf->Cell(0,20,'Karimnagar 505001 - Telangana',0,0);

$pdf->Ln(5);
$pdf->SetFont('Arial','',8);
$pdf->Cell(0,20,'Email us : info@zippyneeds.com  | Mobile : +91 958535191',0,0);

// Shipping Address

$pdf->Ln(18);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(0,0,'Billing Address',0,1);


$pdf->Ln(0);
$pdf->SetFont('Arial','',8);
$pdf->Cell(0,10,"{$address}",0,0);

$pdf->Ln(0);
$pdf->SetFont('Arial','',8);
$pdf->Cell(0,20,"{$landmark}",0,0);

$pdf->Ln(5);
$pdf->SetFont('Arial','',8);
$pdf->Cell(0,20,"Name : {$name}   |   Mobile : +91 {$mobile}",0,0);

$pdf->Ln(5);
$pdf->SetFont('Arial','B',8);
$pdf->Cell(0,20,"Delivery Date : {$delivery_date}   |   Time :{$delivery_slot}",0,0);



$pdf->Ln(20);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(10,8,'sno',1,0,'C');
$pdf->SetFont('Arial','B',10);
$pdf->Cell(65,8,'Item / Product',1,0);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(45,8,'Item Price',1,0,'C');
$pdf->SetFont('Arial','B',10);
$pdf->Cell(20,8,'Quality',1,0,'C');
$pdf->SetFont('Arial','B',10);
$pdf->Cell(50,8,'Amount',1,1,'C');

	include("code/connect.php");
	include("code/getdetails.php");


$totalsum = 0;
$savings  = 0;
	@$fetc = "select * from orders where userid='$userid' && order_id='$orderid'";
	$nps = mysqli_query($con,$fetc);

	if(mysqli_num_rows($nps)>0){
	    $qtycount = mysqli_num_rows($nps);
	$total =0;
	$no =1;
	while ($nis  = mysqli_fetch_array($nps)) {
		$oid = $nis['id'];
		$orderid = $nis['order_id'];
		$proid = $nis['proid'];
		$bid = $nis['bid'];
		$userid = $nis['userid'];
		$orderqty = $nis['qty'];
		$cartqty = $nis['qty'];
		$orderprice = $nis['price'];
		$orderdate = $nis['date'];
		$orderstatus = $nis['order_status'];
		$disallowed = $nis['discount_allowed'];
		$disamt = $nis['discount_amt'];
		$cashback = $nis['cashback'];
		$dcharges = $nis['delevery_charges'];
		$delivery_date = $nis['delevery_date'];


			if($orderstatus =="pending"){
				$ostatus = "<label style='color:red'>PENDING</label>";
			}elseif($orderstatus =="delevered"){
				$ostatus = "<label style='color:green'>DELEVERED</label>";
			}elseif($orderstatus=="processing"){
				$ostatus = "<label style='color:orange'>PROCESSING</label>";
			}
		
	

		
	$bus = "SELECT * FROM products where id='$proid' && status='active'";
	$lossb = mysqli_query($con,$bus);

		while ($mmse = mysqli_fetch_array($lossb)) {
			$pid = $mmse['id'];
			$date = $mmse['date'];
			$cityid = $mmse['cityid'];
			$catid = $mmse['catid'];
			$title = $mmse['title'];
			$proimage = $mmse['proimage'];
			$disc = $mmse['discription'];
			$price = $mmse['price'];
			$qty_avl = $mmse['qty_avl'];
			$spec1 = $mmse['spec1'];
			$spec2 = $mmse['spec2'];
			$spec3 = $mmse['spec3'];
			$spec4 = $mmse['spec4'];
			$spec5 = $mmse['spec5'];
			$spec6 = $mmse['spec6'];
			$status = $mmse['status'];
			$discount = $mmse['discount'];
			$mprice = $mmse['mprice'];

			$title = substr($title,0,45).'..';

			@$multiprice = $orderprice*$orderqty;
			@$sn  = $disallowed*$orderqty;
			@$valus = array_sum(array($sn));
			@$savings +=$valus;
			// Sum Total Value
			$valuw = array_sum(array($multiprice));
			$totalsum +=$valuw;
		

			if($totalsum <=150){
				$dcharge = 25;
				$payprice = $totalsum+$dcharge;
			}else{
				$dcharge = 0;
				$payprice = $totalsum;
			}


?>
<?php
		

		

$pdf->SetFont('Arial','',8);
$pdf->Cell(10,6,"$no",1,0,'C');
$pdf->SetFont('Arial','',8);
$pdf->Cell(65,6,"{$title}",1,0);

$pdf->SetFont('Arial','',8);
$pdf->Cell(45,6,"{$orderprice}",1,0,'C');
$pdf->SetFont('Arial','',8);
$pdf->Cell(20,6,"{$orderqty}",1,0,'C');
$pdf->SetFont('Arial','',8);
$pdf->Cell(50,6,"{$multiprice}",1,1,'C');

$no++;

}

}


	}		
}


// Total Section
$pdf->Ln(5);
$pdf->SetFont('Arial','',8);
$pdf->Cell(10,6,'',0,0);
$pdf->SetFont('Arial','',8);
$pdf->Cell(65,6,'',0,0);
$pdf->SetFont('Arial','',8);
$pdf->Cell(45,6,'',0,0);
$pdf->SetFont('Arial','',10);
$pdf->Cell(30,8,'Sub-Total : ',0,0,'R');

$pdf->SetFont('Arial','',10);
$pdf->Cell(30,8,"{$totalsum}",0,1,'C');


$pdf->SetFont('Arial','',8);
$pdf->Cell(10,6,'',0,0);
$pdf->SetFont('Arial','',8);
$pdf->Cell(65,6,'',0,0);
$pdf->SetFont('Arial','',8);
$pdf->Cell(45,6,'',0,0);
$pdf->SetFont('Arial','',10);
$pdf->Cell(30,5,'Delivery Charges : ',0,0,'R');

$pdf->SetFont('Arial','',10);
$pdf->Cell(30,5,"{$dcharge}",0,1,'C');


// $pdf->SetFont('Arial','',8);
// $pdf->Cell(10,6,'',0,0);
// $pdf->SetFont('Arial','',8);
// $pdf->Cell(65,6,'',0,0);
// $pdf->SetFont('Arial','',8);
// $pdf->Cell(45,6,'',0,0);
// $pdf->SetFont('Arial','',10);
// $pdf->Cell(30,10,'Total Savings: ',0,0,'R');

// $pdf->SetFont('Arial','',10);
// $pdf->Cell(30,10,"{$savings}",0,1,'C');


$pdf->SetFont('Arial','',8);
$pdf->Cell(10,6,'',0,0);
$pdf->SetFont('Arial','',8);
$pdf->Cell(65,6,'',0,0);
$pdf->SetFont('Arial','',8);
$pdf->Cell(45,6,'',0,0);
$pdf->SetFont('Arial','',15);
$pdf->Cell(30,10,'Payable Amount  : ',0,0,'R');

$pdf->SetFont('Arial','',15);
$pdf->Cell(30,10,"{$payprice}/-",0,0,'C');

$pdf->Ln(30);
$pdf->SetFont('Arial','',10);
$pdf->Cell(0,5,'- Thank you for Your Order-',0,1,"C");
$pdf->Cell(0,5,' If You have any Questions about this invoice, Contact us ',0,1,"C");
$pdf->Cell(0,8,'- +91 95158-57853  |  support@zippyneeds.com -',0,1,"C");

$pdf->Output();



?>