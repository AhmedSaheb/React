<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
			

<div class="bodytouch">

<h3>Password Update</h3>
<hr>

<p>Manage and Update your profile Password here.</p>
<br>

<div class="row">
<div class="col-md-6 col-md-offset-0">

<div id="passupdate"></div>

<form action="" method="POST">

<label>New Password</label>	
<input type="text" id="oldpass" class="form-control" name="oldpass" placeholder="Enter Your Password">

<label>Retype Password</label>	
<input type="password" id="newpass" class="form-control" name="newpass" placeholder="New Password">

<button type="submit" name="updatepassword" id="uppass" class="btn">Confirm to Update </button>
</form>
</div>
</div>






</div>

	</div>
</div>

</div>
</div>

</body>
</html>