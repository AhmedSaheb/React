<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); ?>			

<script>
    $(document).ready(function(){
        $("#discount").keyup(function(){
            var sprice = $("#sprice").val();
            var discount = $("#discount").val();
            
            var mydp = sprice*discount/100;
            var mysalep = sprice-mydp;
            var show = Math.round(mysalep);
            
            $("#dp").val(show);
        });
    });
</script>  

<div class="bodytouch">


<?php include("code/view_company.php"); ?>
<!-- 	<?php include("code/update_business.php"); ?> -->

<div class="row">
	<div class="col-md-6 col-md-offset-0">

	<h3>Create New Offers</h3>
	<h5>Creating New offer updateing and Manage Offers </h5> 
	<hr>

<!-- 	<?php include("code/update_business.php"); ?> -->

	<form action="" method="POST">

	<input type="hidden" name="gid" id="gid" value="<?php echo $cid ?>">	

	<label>Offer Title <span>*</span></label>
	<input type="text" class="form-control" placeholder="Offer Title" name="title" id="title">
	
	<label>Product Image</label>
	<input type="file" name="file" id="file" class="form-control">

	<label>Product Price</label>
	<input type="text" name="sprice" id="sprice" class="form-control"  placeholder="Selling Price">
	
	<!--<label>Discount</label>-->
	<!--<input type="number" name="discount" id="discount" class="form-control" placeholder="Discount">-->


	<!--<label>Selling Price</label>-->
	<!--<input type="number" name="dp" id="dp" class="form-control" placeholder="Selling Price" disable>-->

	<!--<label>Offer Start Date</label>-->
	<!--<input type="date" name="sdate"  id="sdate"  class="form-control">-->
	
	<!--<label>Offer End Date</label>-->
	<!--<input type="date" name="edate"  id="edate"  class="form-control">-->

	<button class="btn" type="submit" name="submit" id="submit">Create New Offer</button>
</form>
</div>
</div>

</div>





</div>

	</div>
</div>

</div>
</div>

</body>
</html>