<?php session_start(); ?>
<?php include('files/header.php'); ?>

<style type="text/css">
	body{
	background: #2f3640;
}
.priview{
    display:none;
}
</style>



<div class="container">

<div class="row">

	<div class="col-md-4 col-md-offset-4">
<div class="loginf">
			<div id="showlogin"></div>

		<h4>BUSINESS PANEL</h4>
		<br>
		<label>Login to Your Account</label>


		<form action="" method="POST">
			<input type="text" class="form-control" name="uid" id="uid" placeholder="User ID">
			<input type="password" class="form-control" name="password" id="password" placeholder="Password">
			<button class="btn" type="submit" name="login" id="login">Login to Account <i class="fa fa-sign-in" aria-hidden="true"></i></button>
		</form>
		<br>
<!-- 		<a href="forget-password">Forget Password?</a> -->
	</div>	
	
</div>
</div>
</div>



</body>
</html>