<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); 
?>			

<div class="bodytouch">


<h3>Add Social Media Links</h3>
	<h5>Update Manage your Business Social links.</h5>
	<hr>	

<div id="updatesocial"></div>
<!-- 	<?php include("code/add_sociallinks.php"); ?> -->
<!-- 	<?php include("code/view_sociallinks.php"); ?>
 -->

<?php include("code/remove_sociallinks.php"); ?>

<div class="row">
	<div class="col-md-6 col-md-offset-0">

	<form action="" method="POST">

	<input type="hidden" value="<?php echo $linkid ?>" name="gid" id="gid">	
	<label>Choose Social Link</label>
	<select class="form-control" name="site" id="site">
		<option value="">Choose Social Links</option>

		<?php
		 include("code/connect.php");
		 include("code/getdetails.php");

		$sels = "select * from sociallinks where status='active'";
		 $nns = mysqli_query($con,$sels);
		 while ($op =mysqli_fetch_array($nns)) {
		 	$sid  = $op['id'];
		 	$name  = $op['name'];
		 	$icon  = $op['icon'];
		 	$status  = $op['status'];
		 	echo "<option value='$sid'>$name</option>";
		 }

		 ?>

		
	

	</select>

	<input type="text" class="form-control" placeholder="Url with http or https" name="link" id="link">


	<button class="btn" type="submit" name="submit" id="submit">Submit</button>
</div>
</div>
</form>

<br><br><br>
<div class="table table-responsive">
<?php include("code/fetch_sociallinks.php"); ?>

</table>


</div>


</div>
</div>
</div>
</div>






</div>

	</div>
</div>

</div>
</div>

</body>
</html>