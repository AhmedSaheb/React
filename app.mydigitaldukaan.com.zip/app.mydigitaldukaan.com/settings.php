<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); ?>			

<div class="bodytouch">

<h3>Settings</h3>
<hr>

<p>Manage and Update your profile settings here.</p>
<br>
<?php include("code/getdetails.php"); ?>

<div class="row">
<div class="col-md-6 col-md-offset-0">

<!-- <div id="updatepro"></div> -->
<?php include("code/update_profile.php"); ?>

<form action="" method="POST" enctype="multipart/form-data">

<label>UserId</label>	
<input type="text" class="form-control" value="<?php echo $userid ?>" placeholder="UserId" disabled>


<label>Your Name</label>	
<input type="text" id="name" class="form-control" value="<?php echo $bname ?>" name='name' placeholder="Your Name">

<label>Your Role</label>	
<input type="text" id="role" class="form-control" value="<?php echo $rolw ?>" name='role' placeholder="Your Role">

<label>Your Email</label>	
<input type="email" id="email" class="form-control" value="<?php echo $bemail ?>" name="email" placeholder="Your Email">

<label>Update Profile</label>
<input type="file" id="file" class="form-control" name='file'>
<input type="hidden" id="gfile" class="form-control" value="<?php echo $profile ?>" name='gfile'>

<label>Your Mobile</label>	
<input type="number" id="mobile" class="form-control" value="<?php echo $bmobile ?>" name="mobile" placeholder="Your Mobile">
<button class="btn" type="submit" name="update" >Submit </button>

</form>
</div>
</div>






</div>

	</div>
</div>

</div>
</div>

</body>
</html>