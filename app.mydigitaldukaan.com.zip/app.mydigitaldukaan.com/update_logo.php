<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); 
?>			

<div class="bodytouch">

<h3>Update Company Logo</h3>
<hr>
<p>Manage and Update your Company Logo here.</p>
<br>

<div class="row">
<div class="col-md-8 col-md-offset-0">

<div id="showregister"></div>
	<?php include("code/view_logo.php"); ?>
<?php include("code/update_logo.php"); ?>


	<h3>Company Logo</h3>
	<h5>Update your Company logo.</h5>
	<hr>
	<form action="" method="POST" enctype="multipart/form-data">
	
	<label>Upload Logo Format PNG,JPG,JPEG</label>

	<input type="file" name="file" id="file" class="form-control" onchange="upload(this.value)">

	<input type="hidden" name="glogo" id="glogo" value="<?php echo $glogo ?>">
	<input type="hidden" name="logoid" id="logoid" value="<?php echo $logoid ?>">
	<button class="btn" type="update" name="update" >Update Logo</button>

	</form>




<div class="dlogo" style="padding: 30px;">
	<h4>Active Logo</h4>
	<hr>


	<img src="http://smartdigitalvcard.com/images/company_logo/<?php echo $glogo ?>" style='height: 80px;'>
</div>
</div>
</div>






</div>

	</div>
</div>

</div>
</div>

</body>
</html>