<?php  
 include("code/connect.php");
 include("code/getdetails.php");

$sels = "select * from vc_sociallinks where bcode='$umcode'";
 $nns = mysqli_query($con,$sels);
 while ($op =mysqli_fetch_array($nns)) {
 	$linkid  = $op['id'];
 	$bcode  = $op['bcode'];
 	$tsid  = $op['sid'];
 	$slink  = $op['link'];
 	$sstatus  = $op['status'];
 }

 $selsr = "select * from sociallinks where id='$linkid'";
		 $nns = mysqli_query($con,$selsr);
		 while ($ops =mysqli_fetch_array($nns)) {
		 	$esid  = $ops['id'];
		 	$ename  = $ops['name'];
		 	$eicon  = $ops['icon'];
		 	$estatus  = $ops['status'];
}


?>
