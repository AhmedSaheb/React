
<?php


if(isset($_POST['submit'])){

include('connect.php');
include("getdetails.php");

$newpass = $_POST['newpass'];
$oldpass = $_POST['oldpass'];

if($newpass=="" || $oldpass=="" ){
	echo "<div class='ferror bounceIn'>Please Fill all Fields !</div>";
}else{

$salt = "3232156aksjsdln";
$old = $oldpass.$salt;
$shap = sha1($old);

$log = "select * from ms_uers where id='$mid' && password='$shap'";
$ppp = mysqli_query($con,$log);
if(mysqli_num_rows($ppp)>0){

$salt2 = "3232156aksjsdln";
$ids = $newpass;
$ps = $ids.$salt2;
$password = sha1($ps);

$updatepass = "update ms_uers set password='$password' where id='$mid'";
if(mysqli_query($con,$updatepass)){
echo "<div class='fsuccess bounceIn'>
	Updated Successfully !
</div>";
}else{
echo "<div class='ferror bounceIn'>Error on Update !</div>";
}

}else{
	echo "<div class='ferror bounceIn'>Your Password is Not Correct !</div>";
}


}
}


// }

?>

