<?php 
	
	include('connect.php');
	
	
	if(isset($_POST['submit'])){

		@$email = $_POST['otp'];

		if($email==''){
			echo "<div class='container error'>Enter OTP CODE</div>";
		}else{

		$selpass = "select * from members where otp='$email'";
		$ps = mysqli_query($con,$selpass);
		if(mysqli_num_rows($ps)){
		
		$iddata = "1321321654654987896543131";
		$rand = substr(str_shuffle($iddata),0,5);

		$selpass = "select * from members where otp='$email'";
		$ps = mysqli_query($con,$selpass);
		while ($san = mysqli_fetch_array($ps)) {
			$sendmobile  = $san['mobile'];
		}

		$iddata = "1321321654654987896543131";
		$otp = substr(str_shuffle($iddata),0,5);

		$salt2 = "3232156aksjsdln";
		$ids = "1234567890987654321124578986532";
		$newpass= substr(str_shuffle($ids),0,5);
		$ps = $newpass.$salt2;
		$password = sha1($ps);

		
		$up = "update members set password='$password',otp='$otp' where otp='$email'";
		if(mysqli_query($con,$up)){
		
		$link = "your password is updated to $newpass\nat SmartDigitalVcard";
	@$cus_urls1 = "http://onlinebulksmslogin.com/spanelv2/api.php?username=zippyneeds&password=zippyneeds7222&to=$sendmobile&from=ZIPPYN&message=".urlencode($link);
		@$cis = file_get_contents($cus_urls1);
		

			echo "<div class='container success'>Successfull Redirecting... !</div>";
			echo "<script>window.open('login.php','_self');</script>";
	}else{
			echo "<div class='container error'>Password Reset Error !</div>";
		}

		}else{
			echo "<div class='container error'>INVALID OTP CODE !</div>";
		}



}	

	}
?>