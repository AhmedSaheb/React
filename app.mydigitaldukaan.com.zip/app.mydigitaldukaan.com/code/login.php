<?php 
	

if(isset($_POST['login'])){
	include('connect.php');

		$uid = $_POST['uid'];
	
		$salt = "3232156aksjsdln";
		$pass = $_POST['password'].$salt;
		
		if($uid=='' || $pass==''){
			echo "<div class='lerror bounceIn'>Please Enter Your Credentials</div>";
		}else{

		$shap = sha1($pass);
		$loge = "select * from vc_members where userid='$uid' && password='$shap' && status='active'";
		$pppe = mysqli_query($con,$loge);
		while ($oopse = mysqli_fetch_array($pppe)) {
			@$userid = @$oopse['id'];
		}

		@$sel_user = "select * from vc_members where id='$userid' && password='$shap' && status='active'";
		$pss = mysqli_query($con,$sel_user);
		if(mysqli_num_rows($pss)>0){

		session_start();		

		$uid 	  = $_SESSION['uid']=$userid;
		$password = $_SESSION['password']=$pass;
		  echo "<div class='lsuccess bounceIn'>Login Success Redirecting....</div>";   
		  echo "<script>window.open('dashboard','_self');</script>";
	
		}else{
			echo "<div class='lerror bounceIn'>Invalid Credentails !</div>";
		}

	}
}	
?>