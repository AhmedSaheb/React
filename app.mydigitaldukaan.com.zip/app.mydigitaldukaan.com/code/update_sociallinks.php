<?php 
	


if(isset($_POST['submit'])){

$link = $_POST['link'];
$site = $_POST['site'];
@$gid  = $_POST['gid'];

@include("connect.php");
@include("getdetails.php");	

$check = "select * from vc_sociallinks where sid='$site' && bcode='$umcode'";
$ssp = mysqli_query($con,$check);
if(mysqli_num_rows($ssp)>0){
	echo "<div class='error'>Alerady Available on List!</div>";
}else{

$update = "insert into vc_sociallinks (sid,link,bcode,status)value('$site','$link','$umcode','active')"; 
if(mysqli_query($con,$update)){
echo "<div class='success bounceIn'>Social Links Updated Successfully !</div>";
}else{
echo "<div class='error bounceIn'>Error on Category Listing !</div>";
}
}
}

?>