<?php 
	
if(isset($_POST['submit'])){

$title = $_POST['title'];
$button = $_POST['button'];
$price = $_POST['price'];
$cat = $_POST['cat'];
$offertype = $_POST['offertype'];

$mmsg = nl2br($_POST['disc']);
$disc = mysqli_real_escape_string($con,$mmsg);

$type  = "normal";
$status  = "active";

@include("code/connect.php");
@include("code/getdetails.php");	


function compressedimage($source, $path, $quality){
		$info = getimagesize($source);

		if($info['mime'] == 'image/jpeg'){
			$image = imagecreatefromjpeg($source);
		}elseif($info['mime'] == 'image/gif'){
			$image = imagecreatefromgif($source);
		}elseif($info['mime'] == 'image/png'){
			$image = imagecreatefrompng($source);
		}
		imagejpeg($image, $path, $quality);
}

		


// Getting File name
	$filename = $_FILES['file']['name'];
	
	if($title == "" || $filename == ""){
		echo "<div class='error bounceIn'>Please Select Files !</div>";
	}else{

	// Check Extentions
	$valid_ext = array('png','jpeg','jpg');
	// Break Extention
	$photoExt1 = @end(explode('.', $filename));
	$phototest1 = strtolower($photoExt1);
	// Change Name

	if($filename != ""){
		$new_profile_pic = time().'.'.$photoExt1;
	// File Location
	$location = "../mydigitaldukaan.com/images/company_service/".$new_profile_pic;
	// file Extentions
	$file_extention = pathinfo($location, PATHINFO_EXTENSION);
	$file_extention = strtolower($file_extention);
	// Check Extention
	if(in_array($file_extention,$valid_ext)){
		// CompressImage Code
compressedimage($_FILES['file']['tmp_name'],$location,20);




$check = "insert into vc_services(offertype,disc,catid,bcode,title,image,status,price,button)value('$offertype','$disc','$cat','$umcode','$title','$new_profile_pic','$status','$price','$button')";
	
if(mysqli_query($con,$check)){
echo "<div class='success bounceIn'>Added Successfully !</div>";
}else{
echo "<div class='error bounceIn'>Error on Category Listing !</div>";
}
}
}
}

}
?>