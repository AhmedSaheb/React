
<?php 
	
	include("connect.php");
	include("getdetails.php");
	$sno = 0;
	
	echo "
		<table class='table table-bordered'>

		<tr>
			<th>SNO</th>
			<th>Title</th>
			<th>Link</th>
			<th>Action</th>
		</tr>
	";

	$f = "select * from vc_videos where bcode='$umcode' order by id DESC";
	$lo = mysqli_query($con,$f);
	while ($nn = mysqli_fetch_array($lo)){
		$sid = $nn['id'];
		$title = $nn['title'];
		$link = $nn['file'];
		$status = $nn['status'];
	$sno = $sno+1;
	
echo "
	<tr>
			<td>$sno</td>
			<td>$title</td>
			<td>$link</td>
			<td><a href='update-videos?r=$sid'>Remove</a></td>
		</tr>
";

	}

?>
