<?php 
	

if(isset($_GET['r'])){
		$r= $_GET['r'];
include("code/connect.php");
include("code/getdetails.php");

	$del = "delete from vc_cservice where bcode='$umcode' && id='$r'";
	$ssp = mysqli_query($con,$del);
	if(mysqli_query($con,$del)){
		echo "<div class='success'>List Removed Succssfully !</div>";
	}else{
		echo "<div class='success'>List Removed Error !</div>";
	}

	}
?>