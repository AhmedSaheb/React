
<?php

include('connect.php');

if(isset($_POST['submit'])){
$name = $_POST['name'];
$mobile = $_POST['mobile'];
$package = $_POST['package'];
$email = $_POST['email'];
$cname = $_POST['cname'];

$bbid = "1321321654654987896543131";
$mcode = substr(str_shuffle($bbid),0,4);
$ids = "1234567890987654321124578986532";
$c_is= substr(str_shuffle($ids),0,5);
$memberid = "DC".$c_is;

$salt2 = "3232156aksjsdln";
$ids = "1234567890987654321124578986532";
$newpass= substr(str_shuffle($ids),0,5);
$ps = $newpass.$salt2;
$password = sha1($ps);


$otpcode = "1234567890987654321124578986532";
$otp= substr(str_shuffle($otpcode),0,6);

$ipaddress = $_SERVER['REMOTE_ADDR'];
date_default_timezone_set('Asia/Kolkata');
$date = date("d-m-Y");

if($name=="" || $mobile==""){
echo "<div class='error'>Fields are Empty !</div>";
}else{


$seluser = "select * from vc_members where mobile='$mobile'";
$sps = mysqli_query($con,$seluser);
if(mysqli_num_rows($sps)>0){
echo "<div class='error'>Mobile is used with other Account !</div>";
}else{


$seluseremail = "select * from vc_members where email='$email'";
$spse = mysqli_query($con,$seluseremail);
if(mysqli_num_rows($spse)>0){
echo "<div class='error'>Email is used with other Account ! !</div>";
}else{

$type = "user";
$status = "active";
$package = "standard";


$inst = "insert into vc_members(email,user_code,date,name,mobile,package,password,status,type,otp,linkname)value('$email','$memberid','$date','$name','$mobile','$package','$password','$status','$type','$otp','$cname')";
if(mysqli_query($con,$inst)){

	// mkdir("../".$cname);	
	// mkdir("../".$cname."/code");
	// mkdir("../".$cname."/files");
	// copy("../demofolder/index.php", "../".$cname."/index.php");
	// copy("../demofolder/code/configfile.php", "../".$cname."/code/configfile.php");
	// copy("../demofolder/code/connect.php", "../".$cname."/code/connect.php");
	// copy("../demofolder/code/getdetails.php", "../".$cname."/code/getdetails.php");
	// copy("../demofolder/files/header.php", "../".$cname."/files/header.php");

	// $myfile = fopen("../".$cname."/code/configfile.php", "w") or die("Unable to open file!");
	 
	// $txt = '<?php $userid="'.$memberid.'";	 
	 // fwrite($myfile, $txt);
	 // fclose($myfile);

	//  Add Themes
	$uptheme = "insert into vc_themes (bcode,theme,status)values('$memberid','1','active')";
	mysqli_query($con,$uptheme);

	$default = "default";

	//  Add business
	$upbus = "insert into vc_business(bcode,company,tagline,cemail,cmobile,caddress,cabout,cmapslink,website,status)values('$memberid','$cname','$default','$default','$default','$default','$default','$default','$default','$default')";
	mysqli_query($con,$upbus);


	//  Add Clogo
	$uplogo = "insert into vc_clogo (bcode,logo,alt,status)values('$memberid','default.jpg','1','active')";
	mysqli_query($con,$uplogo);	

echo "<div class='success'>Registration Successfully Reditecting. !</div>";
$link = "Verification code $otp for Coderhex Technologies";

// @$cus_urls1 = "http://onlinebulksmslogin.com/spanelv2/api.php?username=zippyneeds&password=zippyneeds7222&to=$mobile&from=ZIPPYN&message=".urlencode($link);

// 	@$cis = file_get_contents($cus_urls1);
echo "<script>window.open('conform-otp?mobile=$mobile','_self');</script>";

}else{
echo "<div class='error'>Newtwork Error Please Try Again</div>";
}

}

}
}}

?>

