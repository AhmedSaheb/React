 <?php 
 if(isset($_GET['d'])){
 include("code/connect.php");
 include("code/getdetails.php");

	$did = $_GET['d'];

	$remove= "delete from vc_sociallinks where id='$did' && bcode='$umcode'";
	if(mysqli_query($con,$remove)){
		echo "<div class='success'>Social Link Removed Successfull !</div>";	
	}else{
		echo "eroor";
	}
}

 ?>
