<?php 
	


if(isset($_POST['submit'])){
$title = $_POST['title'];
$status = $_POST['status'];

@include("code/connect.php");
@include("code/getdetails.php");	

if($title=="" || $status==""){
	echo "<div class='error bounceIn'>Fields are Empty !</div>";
}else{

$selcat = "select * from bus_cat where bcode='$umcode' && title='$title'";
$ssm = mysqli_query($con,$selcat);

if(mysqli_num_rows($ssm)>0){
 echo "<div class='error bounceIn'>Categeory Already Available in List !</div>";  
}else{

$update = "insert into bus_cat(bcode,title,status)value('$umcode','$title','$status')";

if(mysqli_query($con,$update)){
echo "<div class='success bounceIn'>Category Added Successfully !</div>";
}else{
echo "<div class='error bounceIn'>Error on Category Listing !</div>";

}
}
}
}
?>