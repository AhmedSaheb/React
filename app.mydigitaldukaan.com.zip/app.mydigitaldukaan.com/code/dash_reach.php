<?php  
 include("code/connect.php");
 include("code/getdetails.php");

date_default_timezone_set('Asia/Kolkata');
$date = date("d-m-Y");

 $totalreach = 0;
 $todayreach = 0;
 $selm = "select * from reach where bcode='$umcode'";
 $nns = mysqli_query($con,$selm);

  $totalreach = mysqli_num_rows($nns);

 $selw = "select * from reach where date='$date' && bcode='$umcode'";
 $nnso = mysqli_query($con,$selw);

 $todayreach = mysqli_num_rows($nnso);

 ?>