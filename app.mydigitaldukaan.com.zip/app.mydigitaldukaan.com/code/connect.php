<?php 
    $s = "localhost";
    $u = "vamtafbg_sabamotu";
    $p = "saba@motu";
    $db = "vamtafbg_dcards";
    $con = new mysqli($s,$u,$p,$db);
    if($con->connect_error){
        echo $conn ->connect_error;
    }else{
        echo "";
    }   
    
    // $s = "localhost";
    // $u = "vamtafbg_easydiscount";
    // $p = "easydiscount228256";
    // $db = "vamtafbg_easydiscount";
    // $con = new mysqli($s,$u,$p,$db);
    // if($con->connect_error){
    //     echo $conn ->connect_error;
    // }else{
    //     echo "";
    // }   
 ?>