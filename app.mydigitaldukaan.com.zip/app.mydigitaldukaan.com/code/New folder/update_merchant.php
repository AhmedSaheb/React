
<?php

include('connect.php');
include('getdetails.php');

if(isset($_POST['submit'])){

$name = $_POST['name'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$status = $_POST['status'];
@$gid = $_POST['gid'];

$bbid = "1321321654654987896543131";
$mcode = substr(str_shuffle($bbid),0,4);
$ids = "1234567890987654321124578986532";
$c_is= substr(str_shuffle($ids),0,5);
$memberid = "DC".$c_is;

$salt2 = "3232156aksjsdln";
$ids = "1234567890987654321124578986532";
$newpass= substr(str_shuffle($ids),0,5);
$ps = $newpass.$salt2;
$password = sha1($ps);


$otpcode = "1234567890987654321124578986532";
$otp= substr(str_shuffle($otpcode),0,6);

$ipaddress = $_SERVER['REMOTE_ADDR'];
date_default_timezone_set('Asia/Kolkata');
$date = date("d-m-Y");

if($name=="" || $mobile==""){
echo "<div class='error bounceIn'>Fields are Empty !</div>";
}else{


$seluser = "select * from vc_members where mobile='$mobile' && code!='$code'";
$sps = mysqli_query($con,$seluser);
if(mysqli_num_rows($sps)>0){
echo "<div class='error'>Mobile is used with other Account !</div>";
}else{


$seluseremail = "select * from vc_members where email='$email' && code!='$code'";
$spse = mysqli_query($con,$seluseremail);
if(mysqli_num_rows($spse)>0){
echo "<div class='error'>Email is used with other Account ! !</div>";
}else{

$type = "user";
$package = "standard";


$inst = "update vc_members set name='$name', email ='$email', mobile='$mobile',status='$status' where code='$code' && id='$gid'";

if(mysqli_query($con,$inst)){
echo "<div class='success bounceIn'>Merchant Updated Successfull !</div>";
}else{
echo "<div class='error'>Newtwork Error Please Try Again</div>";
}

}}}
}

?>

