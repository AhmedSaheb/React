
<?php  

@include("connect.php");
@include("getdetails.php");

date_default_timezone_set('Asia/Kolkata');
$date = date("d-m-Y");

$totalmer = 0;
$sels = "select * from vc_members where code='$code'";
$nns = mysqli_query($con,$sels);
$totalmer = mysqli_num_rows($nns);

echo "<h2 style='margin-top:-3px;'>$totalmer</h2>";
// echo "<p></p>";
?>