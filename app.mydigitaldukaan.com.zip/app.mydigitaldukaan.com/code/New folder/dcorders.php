
<?php  

@include("connect.php");
@include("getdetails.php");

date_default_timezone_set('Asia/Kolkata');
$date = date("d-m-Y");

$totalinactive = 0;
$sels = "select * from vc_members where code='$code' && status='inactive'";
$nns = mysqli_query($con,$sels);
$totalinactive = mysqli_num_rows($nns);

echo "<h2 style='margin-top:-3px;'>$totalinactive</h2>";
// echo "<p></p>";
?>