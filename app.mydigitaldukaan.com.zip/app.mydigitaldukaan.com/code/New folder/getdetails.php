<?php 
    
    @include('code/connect.php');    
    @$ip_server = $_SERVER['SERVER_ADDR'];
    @session_start();
    @$sid = $_SESSION['uid'];

    // Select Member Details
    @$selu = "SELECT * FROM vc_master WHERE id='$sid'";
    @$res = mysqli_query($con,$selu);
    while (@$mps = mysqli_fetch_array($res)) {
        $mid = $mps['id'];
        $bdate = $mps['date'];
        $bname = $mps['name'];
        $bmobile = $mps['mobile'];
        @$bemail = $mps['email'];
        @$code = $mps['code'];
    }

    
?>
