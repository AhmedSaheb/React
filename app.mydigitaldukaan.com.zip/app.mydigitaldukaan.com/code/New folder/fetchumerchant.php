<?php
	
	include("code/connect.php");
	include("code/getdetails.php");

	if(isset($_GET['id'])){
		$gid = $_GET['id'];
	
	$selcats = "select * from vc_members where id='$gid' && code='$code'";
	$psr = mysqli_query($con,$selcats);

	$sno = 0;	
	while ($ops = mysqli_fetch_array($psr)) {
		$uid	    = $ops['id'];
		$ucode 		= $ops['user_code'];
		$uemail	= $ops['email'];
		$uname		= $ops['name'];
		$umobile	= $ops['mobile'];
		$upac 		= $ops['package'];
		$ustatus 		= $ops['status'];
		$ulink 		= $ops['linkname'];
		$udate 		= $ops['date'];
}
}

?>