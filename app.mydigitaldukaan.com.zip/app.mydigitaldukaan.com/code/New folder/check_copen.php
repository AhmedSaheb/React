<?php 


function copencheck(){
	if(isset($_POST['copen'])){

	@include("connect.php");
	@include("getdetails.php");

	$copen = $_POST['copen'];

	$check ="select * from redemption where copencode='$copen' && status='used' && mconfirm='success'";
	$mmp = mysqli_query($con,$check);
	if(mysqli_num_rows($mmp)>0){
		echo "<span><i style='color:orange; font-weight:bold;'><i class='fa fa-check' aria-hidden='true'></i> Alredy Used<i></span>";
	}else{
	$check ="select * from redemption where copencode='$copen'";
	$mmp = mysqli_query($con,$check);
	if(mysqli_num_rows($mmp)>0){
		echo "<span><i style='color:green; font-weight:bold;'><i class='fa fa-check' aria-hidden='true'></i> Verified<i></span>";
	}else{
		echo "<span><i style='color:red; font-weight:bold;'><i class='fa fa-times' aria-hidden='true'></i> Invalid<i></span>";
	}		
}
	}
}
copencheck();






?>