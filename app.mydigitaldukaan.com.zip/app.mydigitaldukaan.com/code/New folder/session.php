<?php 
	
	@session_start();
	@$_SESSION['uid'];

	if(isset($_SESSION['uid']) && (isset($_SESSION['password']))){
		echo "";
	}else{
		header("location:logout");
	}	

?>