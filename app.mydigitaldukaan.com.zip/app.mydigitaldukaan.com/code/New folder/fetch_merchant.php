<?php
	
	include("code/connect.php");
	include("code/getdetails.php");
	
	$selcats = "select * from vc_members where code='$code' order by id DESC";
	$psr = mysqli_query($con,$selcats);

	$sno = 0;	
	while ($ops = mysqli_fetch_array($psr)) {
		$uid	    = $ops['id'];
		$ucode 		= $ops['user_code'];
		$uemail	= $ops['email'];
		$uname		= $ops['name'];
		$umobile	= $ops['mobile'];
		$upac 		= $ops['package'];
		$ustatus 		= $ops['status'];
		$ulink 		= $ops['linkname'];
		$udate 		= $ops['date'];
		$sno		= $sno+1;



    // Select Member Details
    @$selue = "SELECT * FROM userpackage WHERE bcode='$ucode' order by id DESC";
    @$rese = mysqli_query($con,$selue);
    while (@$mpse = mysqli_fetch_array($rese)) {
        $jdate = $mpse['jdate'];
        $validity = $mpse['validity'];
        $status = $mpse['status'];

	date_default_timezone_set('Asia/Kolkata');
	$date = date("d-m-Y");

    $cdate = strtotime($date);
    $dbdate = strtotime($jdate);
    $diff = $cdate - $dbdate;
    $remdate = floor($diff/(60*60*24));

    $daysleft = $validity-$remdate;

    if($daysleft<0){
    	$rdate = "<span style='color:red; font-weight:bold;'>Expired</span>";
    	$status = "<span style='color:red; font-weight:bold;'>Expired</span>";

    	// Code
    	// User Inactive
    		$updateu = "update vc_members set status='inactive' where user_code='$ucode' && code='$code'";
    		mysqli_query($con,$updateu); 

    	// user Package
    		$updatep = "update userpackage set status='expired' where bcode='$ucode' && code='$code'";
    		mysqli_query($con,$updatep);


    }elseif($daysleft ==0){
    	$rdate = "<span style='color:red; font-weight:bold;'>Today</span>";
		$status = "<span style='color:green; font-weight:bold;'>Active</span>";    	
    }elseif($daysleft <=7 && $daysleft >0){
    	$rdate = "<span style='color:orange; font-weight:bold;'>$daysleft Days</span>";
    	$status = "<span style='color:green; font-weight:bold;'>Active</span>";
    }elseif($daysleft >7){
    	$rdate = "<span style='color:#333; font-weight:bold;'>$daysleft Days</span>";
    	$status = "<span style='color:green; font-weight:bold;'>Active</span>";
    }
 

		echo "
		<tr>
		<td>$sno</td>
		<td>$ulink</td>
		<td>$udate</td>
		<td>$uname</td>
		<td>$uemail</td>
		<td>$umobile</td>
		<td>$upac</td>
		<td>$ustatus</td>
		<td>$status</td>
		<td>$rdate</td>
		<td><a href='update-merchant?id=$uid'>Update</a></td>
	</tr>
		";
}
}

?>