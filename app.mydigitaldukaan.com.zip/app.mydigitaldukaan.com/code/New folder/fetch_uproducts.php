<?php
	
	if(isset($_GET['id'])){
		$pid = $_GET['id'];

	include("code/connect.php");
	
	$selcats = "select * from products where id='$pid'";

	$psr = mysqli_query($con,$selcats);

	while ($ops = mysqli_fetch_array($psr)) {
		$proid	    = $ops['id'];
		$catid 		= $ops['catid'];
		$subcatid		= $ops['subcat'];
		$title 		= $ops['title'];
		$proimage	= $ops['proimage'];
		$disc 		= $ops['discription'];
		$price 		= $ops['price'];
		$qty_avl 	= $ops['qty_avl'];
		$discount 	= $ops['discount'];
		$type 		= $ops['type'];
		$keywords	= $ops['keywords'];
		$status 	= $ops['status'];
		

	$selcat = "select * from cat where id='$catid'";
	$ps = mysqli_query($con,$selcat);
	while ($opse = mysqli_fetch_array($ps)) {
		$cid = $opse['id'];
		$catname = $opse['catname'];

	$subcatme = "select * from subcat where id='$subcatid'";
	$show = mysqli_query($con,$subcatme);
	while ($lols = mysqli_fetch_array($show)) {
			$sid = $lols['id'];
			$subname = $lols['catname'];

	}
	}
	}		
}
?>