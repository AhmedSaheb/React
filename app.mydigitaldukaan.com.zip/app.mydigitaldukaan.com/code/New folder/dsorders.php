
<?php  

@include("connect.php");
@include("getdetails.php");

$totalactive = 0;
date_default_timezone_set('Asia/Kolkata');
$date = date("d-m-Y");

$selM = "select * from vc_members where status='active' && code='$code'";
$nnm = mysqli_query($con,$selM);
$totalactive = mysqli_num_rows($nnm);

echo "<h2 style='margin-top:-3px;'>$totalactive</h2>";
// echo "<p></p>";
?>