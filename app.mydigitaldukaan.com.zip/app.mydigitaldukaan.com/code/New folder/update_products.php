<?php 
	
	@include("code/connect.php");
	@include("code/getdetails.php");

if(isset($_POST['update_product'])){
	$title= $_POST['title'];
	$catid= $_POST['catid'];
	$subcatid= $_POST['subcatid'];
	$price  = $_POST['price'];
	$qty	= $_POST['qty'];
	$keyword= $_POST['keyword'];
	$type   = $_POST['type'];
	$status = $_POST['status'];
	$disc   = $_POST['disc'];
	$discount   = $_POST['discount'];
	$gfile    = $_POST['gfile'];
	$gid      = $_POST['gid'];

	date_default_timezone_set('Asia/Kolkata');
	$date = date("d-m-Y");

	$sps2 = "3216546798798654987655132";
	$proid = substr(str_shuffle($sps2),0,6);

	$photo1 = $_FILES['file']['name'];
	$name_tml1 = $_FILES['file']['tmp_name'];
	$name_type1 = $_FILES['file']['type'];

	$sps1 = "3216546798798654987655132";
	$lol1 = substr(str_shuffle($sps1),0,4);

	$ext1 = explode('.',$photo1);
	$end1 = end($ext1); 

	$file1 = $photo1.'_'.$lol1.'.'.$end1;	
	$city = 1;


if($photo1 == ""){
$update = "update products set catid='$catid',subcat='$subcatid',title='$title',discription='$disc',price='$price',qty_avl='$qty',status='$status',discount='$discount',type='$type',keywords='$keyword' where id='$gid'";

if(mysqli_query($con,$update)){

echo "<div class='success bounceIn'>Product Updated Successfully !</div>";
}else{
echo "<div class='error bounceIn'>Error on Updating Product !</div>";
}

}else{
$update = "update products set catid='$catid',subcat='$subcatid',title='$title',discription='$disc',price='$price',qty_avl='$qty',status='$status',discount='$discount',type='$type',keywords='$keyword',proimage='$file1' where id='$gid'";

if(mysqli_query($con,$update)){
@unlink("../images/item/".$gfile);
move_uploaded_file($name_tml1,"../images/item/".$file1);
echo "<div class='success bounceIn'>Product Updated Successfully !</div>";
}else{
echo "<div class='error bounceIn'>Error on Updating Product !</div>";
}
}





}

?>