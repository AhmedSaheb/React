
<?php

include('connect.php');

if(isset($_POST['update'])){

include("getdetails.php");

$name = $_POST['name'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];

if($name=="" || $mobile=="" || $email==""){
	echo "<div class='error bounceIn'>Please Fill all Fields to Update !</div>";
}else{

$update = "update vc_master set name='$name',mobile='$mobile',email='$email' where id='$mid'";
if(mysqli_query($con,$update)){
echo "<div class='success bounceIn'>
	Profile Updated Successfully !
</div>";
}else{
echo "<div class='error bounceIn'>Error on Apply Please Try Again !</div>";
}}
}


?>

