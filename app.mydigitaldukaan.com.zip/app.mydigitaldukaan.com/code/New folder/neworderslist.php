
<?php  

@include("connect.php");
@include("getdetails.php");

date_default_timezone_set('Asia/Kolkata');
$date = date("d-m-Y");

$sel = "select * from orders where date='$date' && order_status='pending' && order_id !=''";
$nn = mysqli_query($con,$sel);
$neworders = mysqli_num_rows($nn);

echo "
<a href=''>
<span>$neworders</span>
<i class='fa fa-bell-o' aria-hidden='true'></i>
</a>";

?>