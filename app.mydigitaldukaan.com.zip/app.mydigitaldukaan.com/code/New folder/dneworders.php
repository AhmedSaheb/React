
<?php  

@include("connect.php");
@include("getdetails.php");

$neworders = 0;
date_default_timezone_set('Asia/Kolkata');
$date = date("d-m-Y");

$sel = "select * from vc_members where date='$date' && status='active' && code='$code'";
$nn = mysqli_query($con,$sel);
$neworders = mysqli_num_rows($nn);

echo "<h2 style='margin-top:-3px;'>$neworders</h2>";
// echo "<p></p>";
?>