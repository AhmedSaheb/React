<?php 
	
	
	if(isset($_POST['submit'])){
	include('connect.php');
				
		$email = $_POST['uid'];

		if($email==''){
			echo "<div class='container error'>Please Enter Your Email / Mobile !</div>";
		}else{

		$selpass = "select * from members where mobile='$email'";
		$ps = mysqli_query($con,$selpass);
		if(mysqli_num_rows($ps)){

		$iddata = "1321321654654987896543131";
		$otp = substr(str_shuffle($iddata),0,5);

		$selpass = "select * from members where mobile='$email'";
		$ps = mysqli_query($con,$selpass);
		while ($san = mysqli_fetch_array($ps)) {
			$sendmobile  = $san['mobile'];
		}

		
		$up = "update members set otp='$otp' where mobile='$email'";
		if(mysqli_query($con,$up)){
		
		$link = "Submit OTP code : $otp for password reset.\nat ZippyNeeds.com ";

	@$cus_urls1 = "http://onlinebulksmslogin.com/spanelv2/api.php?username=zippyneeds&password=zippyneeds7222&to=$mobile&from=ZIPPYN&message=".urlencode($link);

@$cis = file_get_contents($cus_urls1);

			echo "<div class='container success'>Redirecting... !</div>";
			echo "<script>window.open('conform-otp?mobile=$email','_self');</script>";
		}else{
			echo "<div class='container error'>Error Please Try Again!</div>";
		}

		}else{
			echo "<div class='container error'>Invalid Mobile Number</div>";
		}
}	

	}
?>