
<?php  
 
 include("code/connect.php");
 include("code/getdetails.php");

function neworders(){
 $sel = "select * from orders where order_status='pending' && order_id !=''";
 $nn = mysqli_query($con,$sel);
 $neworders = mysqli_num_rows($nn);
}
neworders();



?>