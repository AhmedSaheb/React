<?php 
    @$s = "localhost";
    @$u = "root";
    @$p = "";
    @$db = "vcars";
    @$con = new mysqli($s,$u,$p,$db);
    if(@$con->connect_error){
        echo @$conn ->connect_error;
    }else{
        echo "";
    }   
    
    // $s = "localhost";
    // $u = "vamtafbg_easydiscount";
    // $p = "easydiscount228256";
    // $db = "vamtafbg_easydiscount";
    // $con = new mysqli($s,$u,$p,$db);
    // if($con->connect_error){
    //     echo $conn ->connect_error;
    // }else{
    //     echo "";
    // }   
 ?>