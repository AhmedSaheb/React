<?php 
		include("code/connect.php");

?>