
<?php 
	
	include("connect.php");
	include("getdetails.php");
	$sno = 0;
	
	echo "
		<table class='table table-bordered'>

		<tr>
			<th>SNO</th>
			<th>Service Title</th>
			<th>Action</th>
		</tr>
	";

	$f = "select * from vc_cservice where bcode='$umcode' order by id DESC";
	$lo = mysqli_query($con,$f);
	while ($nn = mysqli_fetch_array($lo)){
		$sid = $nn['id'];
		$title = $nn['servicename'];
		$status = $nn['status'];
	$sno = $sno+1;
	
echo "
	<tr>
			<td>$sno</td>
			<td>$title</td>
			<td><a href='update-list?r=$sid'>Remove</a></td>
		</tr>
";

	}

?>
