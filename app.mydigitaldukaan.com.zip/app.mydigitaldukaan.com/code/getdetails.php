<?php 
    
    @include('code/connect.php');    
    @$ip_server = $_SERVER['SERVER_ADDR'];
    @session_start();
    @$sid = $_SESSION['uid'];

    // Select Member Details
    @$selu = "SELECT * FROM vc_members WHERE id='$sid'";
    @$res = mysqli_query($con,$selu);
    while (@$mps = mysqli_fetch_array($res)) {
        $mid = $mps['id'];
        $bdate = $mps['date'];
        $bname = $mps['name'];
        $bmobile = $mps['mobile'];
        @$bemail = $mps['email'];
        @$code = $mps['code'];
        @$umcode = $mps['user_code'];
        @$linkname = $mps['linkname'];
        @$profile = $mps['profile'];
        @$rolw = $mps['role'];
        @$type = $mps['type'];
        @$package = $mps['package'];
        @$pacs = $mps['package'];
        @$userid = $mps['userid'];
    }
    
     @$selus = "SELECT * FROM vc_business WHERE bcode='$umcode'";
    @$ress = mysqli_query($con,$selus);
    while (@$mps = mysqli_fetch_array($ress)) {
        $sid = $mps['id'];
    }

    // Select Member Details
    @$selue = "SELECT * FROM userpackage WHERE bcode='$umcode'";
    @$rese = mysqli_query($con,$selue);
    while (@$mpse = mysqli_fetch_array($rese)) {
        $jdate = $mpse['jdate'];
        $validity = $mpse['validity'];
        $status = $mpse['status'];

    date_default_timezone_set('Asia/Kolkata');
    $date = date("d-m-Y");

    $cdate = strtotime($date);
    $dbdate = strtotime($jdate);
    $diff = $cdate - $dbdate;
    $remdate = floor($diff/(60*60*24));

    $daysleft = $validity-$remdate;
        

    if($daysleft<0){
     
        // User Inactive
            $updateu = "update vc_members set status='inactive' where user_code='$ucode' && code='$code'";
            mysqli_query($con,$updateu); 

        // user Package
            $updatep = "update userpackage set status='expired' where bcode='$ucode' && code='$code'";
            mysqli_query($con,$updatep);


    }elseif($daysleft ==0){
        $expire = "<span style='color:red; font-weight:bold;'>Today</span>";
    }elseif($daysleft <=7 && $daysleft >0){
        $expire = "<span style='color:orange; font-weight:bold;'>Ends in $daysleft Days</span>";
    }elseif($daysleft >7){
        $expire = "<span style='color:#333; font-weight:bold;'>Ends in $daysleft Days</span>";
    } 

    }  
?>
