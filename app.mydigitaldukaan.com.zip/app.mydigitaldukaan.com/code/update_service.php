<?php 
	
if(isset($_POST['submit'])){

$title = $_POST['title'];
$gid = $_POST['gid'];
$gfile = $_POST['gfile'];
// $price = $_POST['price'];
// $disc  = $_POST['disc'];
$type  = "normal";
$status  = "active";

@include("code/connect.php");
@include("code/getdetails.php");	

$photo1 	= $_FILES['file']['name'];
$name_tml1  = $_FILES['file']['tmp_name'];
$name_type1 = $_FILES['file']['type'];
$name_size  = $_FILES['file']['size'];

$sps1 = "3216546798798654987655132";
$lol1 = substr(str_shuffle($sps1),0,4);

$ext1 = explode('.',$photo1);
$end1 = end($ext1); 

$file1 = $photo1.'_'.$lol1.'.'.$end1;

if($photo1 ==""){

	$ep = "update vc_services set title='$title' where id='$gid' && bcode='$umcode'";
	if(mysqli_query($con,$ep)){
		echo "<div class='success'>Product Updated !</div>";
	}else{
		echo "<div class='error'>Product Updated Error!</div>";
	}
}elseif(($name_size > 250000)){      
   echo "<div class='error'>File too large. File must be less than 250kb.</div>"; 
}elseif($end1 == "jpg" || $end1 == "png" || $end1 =="jpeg" || $end1 == "PNG" || $end1 == "JPG" || $end1 == "JPEG" ){	
	$ep = "update vc_services set title='$title',image='$file1' where id='$gid' && bcode='$umcode'";
	if(mysqli_query($con,$ep)){
		echo "<div class='success'>Product Updated !</div>";
		@unlink("images/company_service/".$gfile);
		move_uploaded_file($name_tml1,"images/company_service/".$file1);
		
	}else{
		echo "<div class='error'>Product Updated Error!</div>";
	}


}else{
echo "<div class='error'>File Type is Not Accepted upload only Jpeg,jpg,png format.</div>";
}

}

}

?>