<?php  
 include("code/connect.php");
 include("code/getdetails.php");

$sels = "select * from vc_business where bcode='$umcode'";
 $nns = mysqli_query($con,$sels);
 while ($opw =mysqli_fetch_array($nns)) {
 	$cid       		  = $opw['id'];
 	$umcode           = $opw['bcode'];
 	$ccompany         = $opw['company'];
 	$ctagline         = $opw['tagline'];
 	$cemail           = $opw['cemail'];
 	$cmobile          = $opw['cmobile'];
 	$caddress         = $opw['caddress'];
 	$cabout           = $opw['cabout'];
 	$cmaps            = $opw['cmapslink'];
 	$cstatus          = $opw['status'];
 	$cwebsite          = $opw['website'];
 	$csmsg          = $opw['smsg'];
 	$gupiuserid          = $opw['upiuserid'];
 	$gupiusername         = $opw['upiusername'];
 	
	}
?>
