<?php 
	


if(isset($_POST['submit'])){
$title = $_POST['title'];

@include("connect.php");
@include("getdetails.php");	

if($title==""){
	echo "<div class='error bounceIn'>Please Add Something !</div>";
}else{


$update = "insert into vc_cservice(bcode,servicename,status)value('$umcode','$title','active')";

if(mysqli_query($con,$update)){
echo "<div class='success bounceIn'>Service/ Product Added Successfully !</div>";
}else{
echo "<div class='error bounceIn'>Error on Category Listing !</div>";


}
}
}
?>