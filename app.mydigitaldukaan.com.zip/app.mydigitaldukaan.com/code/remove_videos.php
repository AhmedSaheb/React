<?php 
	

if(isset($_GET['r'])){
		$r= $_GET['r'];
include("code/connect.php");
include("code/getdetails.php");

	$del = "delete from vc_videos where bcode='$umcode' && id='$r'";
	$ssp = mysqli_query($con,$del);
	if(mysqli_query($con,$del)){
		echo "<div class='success'>Video Removed Succssfully !</div>";
	}else{
		echo "<div class='success'>Video Removed Error !</div>";
	}

	}
?>