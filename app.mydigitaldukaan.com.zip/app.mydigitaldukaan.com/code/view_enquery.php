<?php  
 include("code/connect.php");
 include("code/getdetails.php");

if(isset($_GET['v'])){
	$eid = $_GET['v'];

$sel = "select * from vc_enquery where id='$eid'";
 $nn = mysqli_query($con,$sel);
 while ($op =mysqli_fetch_array($nn)) {
 	$adid  = $op['id'];
 	$date  = $op['date'];
 	$mobile  = $op['mobile'];
 	$email  = $op['email'];
 	$regarding  = $op['regards'];
 	$message  = $op['message'];
 	$name  = $op['name'];
	}
}
?>
