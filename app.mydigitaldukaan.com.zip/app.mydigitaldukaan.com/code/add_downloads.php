<?php

if(isset($_POST['submit'])){

$title = $_POST['title'];
$status  = "active";

@include("code/connect.php");
@include("code/getdetails.php");	

$photo1 = $_FILES['file']['name'];
$name_tml1 = $_FILES['file']['tmp_name'];
$name_type1 = $_FILES['file']['type'];
$name_size = $_FILES['file']['size'];

$sps1 = "3216546798798654987655132";
$lol1 = substr(str_shuffle($sps1),0,4);

$ext1 = explode('.',$photo1);
$end1 = end($ext1); 

$file1 = $photo1.'_'.$lol1.'.'.$end1;



if($title=="" || $photo1 ==""){
	echo "<div class='error'>Please Add Something !</div>";
}
elseif(($name_size > 250000)){      
   echo "<div class='error'>File too large. File must be less than 250kb.</div>"; 
}
elseif($end1 == "jpg" || $end1 == "png" || $end1 =="jpeg" || $end1 == "PNG" || $end1 == "JPG" || $end1 == "JPEG" || $end1=="PDF" || $end1 =="pdf" || $end1=="xlsx" || $end1 =="docx"){

$check = "insert into vc_downloads(bcode,title,file,status)value('$umcode','$title','$file1','$status')";
	
if(mysqli_query($con,$check)){
	move_uploaded_file($name_tml1,"../smartdigitalvcard.com/images/downloads/".$file1);
echo "<div class='success bounceIn'>File Added Successfully !</div>";
}else{
echo "<div class='error bounceIn'>Error on Category Listing !</div>";
}
}else{
echo "<div class='error'>File Type is Not Accepted upload only Jpeg,jpg,png,docx,pdf,xlsx format.</div>";
}


}


?>
