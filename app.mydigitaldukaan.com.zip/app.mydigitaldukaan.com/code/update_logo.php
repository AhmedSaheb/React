<?php 

if(isset($_POST['update'])){
@$logoid= $_POST['logoid'];
@$glogo= $_POST['glogo'];

@include("code/connect.php");
@include("code/getdetails.php");

     function compressedimage($source, $path, $quality){
		$info = getimagesize($source);

		if($info['mime'] == 'image/jpeg'){
			$image = imagecreatefromjpeg($source);
		}elseif($info['mime'] == 'image/gif'){
			$image = imagecreatefromgif($source);
		}elseif($info['mime'] == 'image/png'){
			$image = imagecreatefrompng($source);
		}
		imagejpeg($image, $path, $quality);
      }	
	
        // Getting File name
		$filename = $_FILES['file']['name'];
		// Check Extentions
		$valid_ext = array('png','jpeg','jpg');
		// Break Extention
		$photoExt1 = @end(explode('.', $filename));
		$phototest1 = strtolower($photoExt1);
		// Change Name

	$new_profile_pic = time().'.'.$photoExt1;
	// File Location
	$location = "../mydigitaldukaan.com/images/company_logo/$new_profile_pic";
	// file Extentions
	$file_extention = pathinfo($location, PATHINFO_EXTENSION);
	$file_extention = strtolower($file_extention);
	// Check Extention
	if(in_array($file_extention,$valid_ext)){
		// CompressImage Code
	compressedimage($_FILES['file']['tmp_name'],$location,20);	
	
	$update = "update vc_clogo set logo='$new_profile_pic' where id='$logoid' && bcode='$umcode'"; 
	if(mysqli_query($con,$update)){
	@unlink("../mydigitaldukaan.com/images/company_logo/".$glogo);
	echo "<div class='success bounceIn'>Logo Updated Successfully !</div>";
	}else{
	echo "<div class='error bounceIn'>Error on Category Listing !</div>";
    }

	}
    
    
    
}

?>