<?php 
	
if(isset($_POST['submit'])){

$company = $_POST['company'];
$tagline = $_POST['tagline'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$caddress = $_POST['address'];
$about = $_POST['about'];
$gmap = $_POST['gmap'];
@$gid  = $_POST['gid'];
$website  = $_POST['website'];
$upiuserid  = $_POST['upiuserid'];
$upiusername  = $_POST['upiusername'];
$smsg  = $_POST['smsg'];

@include("connect.php");
@include("getdetails.php");	

if($company=="" || $tagline=="" || $email=="" || $mobile=="" || $caddress=="" || $gmap==""){
	echo "Please enter all fields !";
}else{

$update = "update vc_business set smsg='$smsg',company='$company',tagline='$tagline',cemail='$email',cmobile='$mobile',caddress='$caddress',cabout='$about',cmapslink='$gmap',website='$website',upiuserid='$upiuserid',upiusername='$upiusername' where bcode='$umcode'"; 
if(mysqli_query($con,$update)){
echo "<div class='success bounceIn'>Business Details updated Successfully !</div>";
}else{
echo "<div class='error bounceIn'>Error on Category Listing !</div>";
}

}
}
?>