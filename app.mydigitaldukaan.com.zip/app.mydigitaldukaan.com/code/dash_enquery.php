<?php  
 include("code/connect.php");
 include("code/getdetails.php");

	date_default_timezone_set('Asia/Kolkata');
	$date = date("d-m-Y");

 $sel = "select * from vc_enquery where bcode='$umcode'";
 $nn = mysqli_query($con,$sel);

 $totalenq = mysqli_num_rows($nn);

 $sels = "select * from vc_enquery where date='$date' && bcode='$umcode'";
 $nns = mysqli_query($con,$sels);

 $todayenq = mysqli_num_rows($nns);

 ?>