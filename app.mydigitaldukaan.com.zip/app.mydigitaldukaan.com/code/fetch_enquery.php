<?php  
 include("code/connect.php");
 include("code/getdetails.php");

 $sel = "select * from vc_enquery where bcode='$umcode'";
 $nn = mysqli_query($con,$sel);
 while ($op =mysqli_fetch_array($nn)) {
 	$adid  = $op['id'];
 	$date  = $op['date'];
 	$mobile  = $op['mobile'];
 	$email  = $op['email'];
 	$regards  = $op['regards'];
 	$message  = $op['message'];

?>

<tr>
<td><?php echo $date ?></td>
<td><?php echo $regards ?></td>
<td><a href="view-enquery?v=<?php echo $adid ?>">View</a></td>
</tr>

<?php } ?>

