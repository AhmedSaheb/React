<?php  
 include("connect.php");
 include("getdetails.php");

 echo "
<table class='table table-bordered table-hover'>
		<tr>
			<th>Sno</th>
			<th>Link</th>
			<th>Action</th>
		</tr>
 ";

$sno  = 0;
$selse = "select * from vc_sociallinks where bcode='$umcode' order by id DESC";
 $nnse = mysqli_query($con,$selse);
 while ($ope =mysqli_fetch_array($nnse)) {
 	$linkid  = $ope['id'];
 	$bcode  = $ope['bcode'];
 	$tsid  = $ope['sid'];
 	$slink  = $ope['link'];
 	$sstatus  = $ope['status'];


 $selsr = "select * from sociallinks where id='$linkid'";
		 $nns = mysqli_query($con,$selsr);
		 while ($ops =mysqli_fetch_array($nns)) {
		 	$esid  = $ops['id'];
		 	$ename  = $ops['name'];
		 	$eicon  = $ops['icon'];
		 	$estatus  = $ops['status'];
}

$sno = $sno+1;

echo "
		<tr>
			<td>$sno</td>
			<td>$slink</td>
			<td><a href='update-sociallinks?d=$linkid'>Remove</a></td>
		</tr>
";



}


?>
