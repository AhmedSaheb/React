<?php  

 include("code/connect.php");

$selsrs = "select * from themes";
 $nnsesw = mysqli_query($con,$selsrs);
 while ($opes =mysqli_fetch_array($nnsesw)) {
 	$bid  		= $opes['id'];
 	$themecode  = $opes['themecode'];
 	$themes 	= $opes['themefile'];
 	$title  	= $opes['title'];
 	$style  	= $opes['status'];
 	$type  		= $opes['type'];

echo "
	<div class='theme'>
		<img src='images/themes/$themes'>
	</div>

	<div class='selbtn'>
		<a href='select-theme?sel=$bid' class='btn'>Select Theme</a>
	</div>


";

}

?>
