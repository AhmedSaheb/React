<?php 
	


if(isset($_POST['submit'])){

$link = $_POST['link'];
$title = $_POST['title'];

@include("connect.php");
@include("getdetails.php");	

if($link=="" || $title==""){
	echo "<div class='error bounceIn'>Please Add Something !</div>";
}else{


$update = "insert into vc_videos(bcode,title,file,status)value('$umcode','$title','$link','active')";

if(mysqli_query($con,$update)){
echo "<div class='success bounceIn'>Video Added Successfully !</div>";
}else{
echo "<div class='error bounceIn'>Error on Category Listing !</div>";


}
}
}
?>