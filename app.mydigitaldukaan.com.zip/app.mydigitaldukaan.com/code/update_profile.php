
<?php

include('connect.php');

function compressedimage($source, $path, $quality){
		$info = getimagesize($source);

		if($info['mime'] == 'image/jpeg'){
			$image = imagecreatefromjpeg($source);
		}elseif($info['mime'] == 'image/gif'){
			$image = imagecreatefromgif($source);
		}elseif($info['mime'] == 'image/png'){
			$image = imagecreatefrompng($source);
		}
		imagejpeg($image, $path, $quality);
	}

if(isset($_POST['update'])){

include("getdetails.php");

$name = $_POST['name'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$role = $_POST['role'];
$gfile = $_POST['gfile'];

// $photo1 = $_FILES['file']['name'];
// $name_tml1 = $_FILES['file']['tmp_name'];
// $name_type1 = $_FILES['file']['type'];
// $name_size  = $_FILES['file']['size'];

// $sps1 = "3216546798798654987655132";
// $lol1 = substr(str_shuffle($sps1),0,4);

// $ext1 = explode('.',$photo1);
// $end1 = end($ext1); 

// $file1 = $photo1.'_'.$lol1.'.'.$end1;	

// Getting File name
		$filename = $_FILES['file']['name'];
		// Check Extentions
		$valid_ext = array('png','jpeg','jpg');
		// Break Extention
		$photoExt1 = @end(explode('.', $filename));
		$phototest1 = strtolower($photoExt1);
		// Change Name

	if($filename != ""){
			$new_profile_pic = time().'.'.$photoExt1;
		// File Location
		$location = "../mydigitaldukaan.com/images/profile/$new_profile_pic";
		// file Extentions
		$file_extention = pathinfo($location, PATHINFO_EXTENSION);
		$file_extention = strtolower($file_extention);
		// Check Extention
		if(in_array($file_extention,$valid_ext)){
			// CompressImage Code
		compressedimage($_FILES['file']['tmp_name'],$location,20);



	$update = "update vc_members set name='$name',mobile='$mobile',email='$email',profile='$new_profile_pic',role='$role' where id='$mid'";
	if(mysqli_query($con,$update)){
	@unlink("../mydigitaldukaan.com/images/profile/".$gfile);
	//move_uploaded_file($name_tml1,"../smartdigitalvcard.com/images/profile/".$new_profile_pic);
	echo "<div class='success bounceIn'>Profile Updated Successfully !</div>";	
	}else{
	echo "<div class='error bounceIn'>Error on Apply Please Try Again !</div>";
	}

	}else{
	    echo "File Formate in Not Correct !";
	}
	}else{

	$update = "update vc_members set name='$name',mobile='$mobile',email='$email',role='$role' where id='$mid'";
	if(mysqli_query($con,$update)){
	echo "<div class='success bounceIn'>Profile Updated Successfully !</div>";	
	}else{
	echo "<div class='error bounceIn'>Error on Apply Please Try Again !</div>";
	}

	}	

	



}



?>

