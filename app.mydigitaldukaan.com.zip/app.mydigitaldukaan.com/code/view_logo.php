<?php  
 include("code/connect.php");
 include("code/getdetails.php");

$sels = "select * from vc_clogo where bcode='$umcode'";
 $nns = mysqli_query($con,$sels);
 while ($op =mysqli_fetch_array($nns)) {
 	$logoid  = $op['id'];
 	$bcode  = $op['bcode'];
 	$glogo  = $op['logo'];
 	$alttext  = $op['alt'];
 	$status  = $op['status'];
 }
?>
