<?php 
	


if(isset($_POST['submit'])){

$link = $_POST['link'];
$site = $_POST['site'];
$gid  = $_POST['gid'];

@include("code/connect.php");
@include("code/getdetails.php");	

if($link=="" || $site=="" || $gid==""){
	echo "Please Add Something !";
}else{

$check = "select * from vc_sociallinks where bcode='$umcode' && sid='$site'";
$ii = mysqli_query($con,$check);
if(mysqli_num_rows($ii)>0){
	echo 'Alerady Available';
}else{

$update = "insert into vc_sociallinks (sid,link,bcode,status)value('$site','$link','$umcode','active')"; 
if(mysqli_query($con,$update)){
echo "<div class='success bounceIn'>Social Links Updated Successfully !</div>";
}else{
echo "<div class='error bounceIn'>Error on Category Listing !</div>";
}
}
}
}
?>