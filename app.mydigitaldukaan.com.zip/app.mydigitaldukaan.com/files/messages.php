<div class="messages">
	<h4>Important Message</h4>
	<p>As per the guidelines set by the GST Authority of India, for all the payments pertaining to the vouchers redeemed on or after 1st October, 2018, nearbuy.com will be deducting 1% of the deal price (customer price) from your payment as TCS (Tax Collection at Source). This amount will be deposited with the authority and can be claimed by you as credit while filing your GST return. Share your GST details here.</p>
</div>