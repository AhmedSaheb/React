<?php include("code/session.php"); ?>
<?php include("code/getdetails.php"); ?>

<div class="topmenu">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 col-xs-3">
				<div class="bar">
					<i class="fa fa-align-left" aria-hidden="true"></i>
				</div>
			</div>

			<div class="col-sm-6 col-xs-6">
				<div class="company">
					<h4><a href='dashboard' style='letter-space:1px; margin-top:2px; font-size:14px;'>BUSINESS PANEL</a></h4>
					</div>
			</div>

		</div>
	</div>
</div>


<div class="mobside">
	<div class="inside">
<i class="fa fa-arrow-left" aria-hidden="true"></i>
		<h4>Welcome Merchant</h4>
		<h3><?php echo $bname ?></h3>
	</div>

	<li><a href="dashboard">Dashboard</a></li>
	<li><a href="manage-business">My Business</a></li>
	<hr>
	<li><a href="password-update">Password</a></li>
	<li><a href="settings">Settings</a></li>
	<li><a href="logout">Logout</a></li>

</div>


<div class="container-fluid">	
	<div class="row">

	<div class="col-md-2 sidemenu">
		<div class="">
		<h3 style="margin-left: 30px; font-size:25px;">BUSINESS PANEL</h3>
			<ul>
			<li><a href="dashboard">Home</a></li>
			<li><a href="manage-business">My Business</a></li>
<!-- 			<li><a href="manage-products">Sales Details</a></li> -->
			<br>
			<li><a href="password-update">Password</a></li>
			<li><a href="settings">Settings</a></li>
			<li><a href="logout">Logout</a></li>

		</ul>
	</div>
</div>

<div class="col-md-10 mainarea">