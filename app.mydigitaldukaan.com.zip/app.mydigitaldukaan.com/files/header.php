<!DOCTYPE html>
<html>
<head>
    
  <base href="/dirtyurl">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="images/icon.png" type="image/gif" alt='favicon'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css"/>

<script src="https://kit.fontawesome.com/c32eccf21b.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script type="text/javascript" src="js/ajax.js"></script>	
<link rel="stylesheet" type="text/css" href="css/mycss.css">
<link rel="stylesheet" type="text/css" href="css/res.css">

<?php include("files/popups.php"); ?>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<!--  <link rel="stylesheet" href="/resources/demos/style.css">-->


<!--<script>-->
<!--$( function() {-->
<!--  $( "#datepickerfrom" ).datepicker({ dateFormat: 'dd-mm-yy' });-->
<!--  dateFormat: 'dd/mm/yy'-->
<!--} );-->
<!--$( function() {-->
<!--  $( "#datepickerto" ).datepicker({ dateFormat: 'dd-mm-yy' });-->
<!--} );-->
<!--</script>-->



<style>

.priview{
    background: rgb(36,0,0);
	background: linear-gradient(90deg, rgba(36,0,0,1) 0%, rgba(244,86,62,1) 0%, rgba(177,15,59,1) 100%);
    border:solid 1px #f2f2f2;
    box-shadow:0px 0px 2px lightgrey;
    border-radius:50px;
    height:70px;
    width:70px;
    position:fixed;
    bottom:20px;
    right:20px;
    z-index:100005;
}
.priview a{
    text-align:center;
    line-height:70px;
    padding-left:5px;
    display:block;
    FONT-SIZE:10PX;
    COLOR:WHITE;
    text-decoration:none;
}
</style>   

<?php include("code/getdetails.php"); ?>

<div class='priview'>
    <a href='https://www.mydigitaldukaan.com/view/<?php echo $sid ?>/<?php echo $linkname ?>' target='_blank'>PREVIEW</a>
</div>


<title>Business Pannel MyDigitalDukaan</title>