<?php include('files/header.php'); ?>

<style type="text/css">
	body{
	background: #2f3640;
}
</style>

<div class="container">	
<div class="row">

	<div class="col-md-6 col-md-offset-3">
<div class="loginf">
		<h4>Reset your easydiscount.in Password</h4>
		<br>
		<label>Please enter your registered email ID / mobile number <span>*</span></label>

		<form action="" method="">
			<input type="text" class="form-control" name="uid" id="uid" placeholder="Email ID / Mobile number">
			<button class="btn" type="submit" name="submit" id="submit">Continue</button>
		</form>
		<br>
		<a href="login">Back to Login</a>

		<br><hr>
		<h4>Not a easydiscount.in business partner? <a href=''>List your business</a></h4>

	</div>	
	
</div>
</div>
</div>



</body>
</html>