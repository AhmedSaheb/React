<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); ?>			

<div class="bodytouch">

<h3>Add New Merchant</h3>
<hr>
<p>Manage and Update your profile settings here.</p>
<br>

<div class="row">
<div class="col-md-8 col-md-offset-0">

<div id="showregister"></div>

<form action="" method="POST" enctype="multipart/form-data">

<label>Company Name</label>	
<input type="text" id="cname" class="form-control" name='cname' placeholder="Company Name" required>

<div class="row">

<div class="col-md-6">
<label>User Name</label>	
<input type="text" id="name" class="form-control" name='name' placeholder="Name" required>
</div>

<div class="col-md-6">
<label>User Email</label>	
<input type="email" id="email" class="form-control" name='email' placeholder="Email" required>
</div>


<div class="col-md-6">
<label>User Mobile</label>	
<input type="number" id="mobile" class="form-control" name='mobile' placeholder="Mobile" required>
</div>


<div class="col-md-6">
<label>Select Package</label>	 
<select class="form-control" name="package" id="package" required>
	<option value="">Select Package</option>
	<option value="starter">Starter Package</option>
</select>
</div>

</div>

<button class="btn" type="submit" name="submit" id="submit" >Create Merchant Account</button>

</form>
</div>
</div>






</div>

	</div>
</div>

</div>
</div>

</body>
</html>