<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); ?>			

<div class="bodytouch">


<?php include("code/view_company.php"); ?>
<!-- 	<?php include("code/update_business.php"); ?> -->

<div class="row">
	<div class="col-md-6 col-md-offset-0">

	<h3>Business Details Update</h3>
	<h5>Update Manage your Business Details here.</h5> 
	<hr>

<!-- 	<?php include("code/update_business.php"); ?> -->
	<div id="updatebusiness"></div>

	<form action="" method="POST">

	<input type="hidden" name="gid" id="gid" value="<?php echo $cid ?>">	

	<label>Business Name</label>
	<input type="text" value="<?php echo $ccompany ?>" class="form-control" placeholder="Business Name" name="company" id="company">

	<label>Business Tagline</label>
	<input type="text" name="tagline" id="tagline" class="form-control" value="<?php echo $ctagline ?>" placeholder="Business Tagline">

	<label>Business Email ID</label>
	<input type="text" name="email" id="email" class="form-control" value="<?php echo $cemail ?>" placeholder="Business Email ID">

	<label>Business Mobile</label>
	<input type="text" name="mobile" id="mobile" class="form-control" value="<?php echo $cmobile ?>" placeholder="Business Mobile Number">

	
	
	<label>UPI USERID</label>
	<input type="text" name="upiuserid" id="upiuserid" value="<?php echo $gupiuserid ?>" class="form-control"/>
	
	
	<label>UPI USERNAME</label>
	<input type="text" name="upiusername" id="upiusername" value="<?php echo $gupiusername ?>"  class="form-control"/>
	
	
	<label>Business Address</label>
	<textarea class="form-control"placeholder="Business Address" name="address" id="address" style='height:120px;'><?php echo $caddress ?></textarea>

	<label>About Business</label>
	<textarea class="form-control" placeholder="About Business" name="about" id="about" style='height:120px;'><?php echo $cabout ?></textarea>

	<label>Website</label>
	<input type="text" name="website" id="website" class="form-control" value="<?php echo $cwebsite ?>" placeholder="Website">

	<label>Google Map Link</label>
	<input type="text" name="gmap"  id="gmap" value="<?php echo $cmaps ?>" class="form-control" placeholder="Google Map Link">

	<label>Share Message (Short Discription)</label>
	<textarea class="form-control"placeholder="Share Message Shot Discription" name="smsg" id="smsg" style='height:120px;'><?php echo $csmsg ?></textarea>

	<button class="btn" type="submit" name="submit" id="submit">Update Business</button>
</form>
</div>
</div>

</div>





</div>

	</div>
</div>

</div>
</div>

</body>
</html>