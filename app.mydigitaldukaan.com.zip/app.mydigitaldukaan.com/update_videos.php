<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); 
?>			


<?php include("code/remove_videos.php"); ?>
<div class="bodytouch">

<h3>Add Youtube Video</h3>
<h5>Adding Video Direct from Youtube with Copy Past URL Code.</h5>
<hr>

<?php include("code/add_videos.php"); ?>

<div id="addvideos"></div>

<div class="row">
	<div class="col-md-6 col-md-offset-0">
	<form action="" method="POST" enctype="multipart/form-data">
	<label>Title</label>
	<input type="text" class="form-control" placeholder="Give a Title for your Video" name="title" id="title">
	<label>Youtube Link</label>
	<input type="text" class="form-control" placeholder="Eg : kkjs4kj34 (Copy and Past the Code find in URL)" name="link" id="link">
	<button class="btn" type="submit" id="submit" name="submit">UPLOAD</button>

</form>
</div>
</div>
<br>

<h4>My Videos</h4>
<hr>
<div class="table table-responsive">
	
<!-- <div id="showvideos"></div> -->
<?php include("code/fetch_videos.php"); ?>		
	</table>
</div>
</div>

</div>

</body>
</html>