
<?php


if(isset($_POST['updatepassword'])){

include('connect.php');
include("getdetails.php");

$newpass = $_POST['newpass'];
$oldpass = $_POST['oldpass'];

if($newpass=="" || $oldpass=="" ){
	echo "<div class='error bounceIn'>Please Fill all Fields !</div>";
}else{

$salt = "3232156aksjsdln";
$old = $oldpass.$salt;
$shap = sha1($old);

$log = "select * from vc_members where id='$mid' && password='$shap'";
$ppp = mysqli_query($con,$log);
if(mysqli_num_rows($ppp)>0){

$salt2 = "3232156aksjsdln";
$ids = $newpass;
$ps = $ids.$salt2;
$password = sha1($ps);

$updatepass = "update vc_members set password='$password' where id='$mid'";
if(mysqli_query($con,$updatepass)){
echo "<div class='success bounceIn'>
	Updated Successfully !
</div>";
}else{
echo "<div class='error bounceIn'>Error on Update !</div>";
}

}else{
	echo "<div class='error bounceIn'>Your Password is Not Correct !</div>";
}


}
}


// }

?>

