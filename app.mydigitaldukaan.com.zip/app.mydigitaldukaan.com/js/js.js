$(document).ready(function(){

$( "#datepicker").datepicker();

$(".bar").click(function(){
	$(".mobside").addClass("sideactive");
});
$(".inside i").click(function(){
	$(".mobside").removeClass("sideactive");
});

//window.oncontextmenu = function(){return false;}

// Close
$(".close").click(function(){
	$(".loginsup").fadeOut();
});

// StoreDetails

$("#deals").show();
$("#clickdeal").click(function(){
	$("#deals").fadeIn();
	$("#about").hide();
	$("#ratings").hide();
});

$("#clickabout").click(function(){
	$("#about").fadeIn();
	$("#deals").hide();
	$("#ratings").hide();
});

$("#clickrating").click(function(){
	$("#ratings").fadeIn();
	$("#deals").hide();
	$("#about").hide();
});

});