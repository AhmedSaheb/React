	
    <script src="js/wow.min.js"></script>
              <script>
              new WOW().init();
              </script>     
