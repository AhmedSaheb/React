$(document).ready(function(){

// Fetch CatList
function showsociallinks(){
	$.ajax({
		url : "code/fetch_sociallinks.php",
		method : "GET",
		dataType : "html",
		success : function(data){
			$("#showsociallinks").html(data);
			showsociallinks();
		}
	});
	}
showsociallinks();


// Fetch Videos
function showvideos(){
	$.ajax({
		url : "code/fetch_videos.php",
		method : "GET",
		dataType : "html",
		success : function(data){
			$("#showvideos").html(data);
			showvideos();
		}
	});
	}
showvideos();


// function neworders(){
// 	$.ajax({
// 		url : "code/dneworders.php",
// 		method : "GET",
// 		dataType : "text",
// 		success : function(data){
// 			$("#neworders").html(data);
// 		}
// 	});
// 	}
// neworders();


// function dporders(){
// 	$.ajax({
// 		url : "code/dporders.php",
// 		method : "GET",
// 		dataType : "text",
// 		success : function(data){
// 			$("#dporders").html(data);
// 		}
// 	});
// 	}
// dporders();

// function dsorders(){
// 	$.ajax({
// 		url : "code/dsorders.php",
// 		method : "GET",
// 		dataType : "text",
// 		success : function(data){
// 			$("#dsorders").html(data);
// 		}
// 	});
// 	}
// dsorders();


// function dcorders(){
// 	$.ajax({
// 		url : "code/dcorders.php",
// 		method : "GET",
// 		dataType : "text",
// 		success : function(data){
// 			$("#dcorders").html(data);
// 		}
// 	});
// 	}
// dcorders();


function addvideos(){
	$("#submit").click(function(pro){
		event.preventDefault(pro);
	

		var title = $("#title").val();
		var link = $("#link").val();
		var gid = $("#gid").val();

	$.ajax({
		url : "code/add_videos.php",
		method : "POST",
		dataType : "html",
		data 	 : {submit:1,title:title,link:link},
		success : function(data){
			$("#addvideos").html(data);
		}
	});
	});
}
addvideos();



function addservicelist(){
	$("#submit").click(function(pro){
		event.preventDefault(pro);
	
		var title = $("#title").val();
		var gid = $("#gid").val();

	$.ajax({
		url : "code/add_list.php",
		method : "POST",
		dataType : "html",
		data 	 : {submit:1,title:title},
		success : function(data){
			$("#add_list").html(data);
		}
	});
	});
}
addservicelist();




function updatebusiness(){
	$("#submit").click(function(pro){
		event.preventDefault(pro);
	

		var company = $("#company").val();
		var tagline = $("#tagline").val();
		var email = $("#email").val();
		var mobile = $("#mobile").val();
		var address = $("#address").val();
		var about = $("#about").val();
		var website = $("#website").val();
		var gmap = $("#gmap").val();
		var gid = $("#gid").val();
		var smsg = $("#smsg").val();
		
var upiuserid = $("#upiuserid").val();
var upiusername = $("#upiusername").val();
	$.ajax({
		url : "code/update_business.php",
		method : "POST",
		dataType : "html",
		data 	 : {submit:1,smsg:smsg,company:company,tagline:tagline,email:email,mobile:mobile,address:address,about:about,gmap:gmap,website:website,upiuserid:upiuserid,upiusername:upiusername},
		success : function(data){
			$("#updatebusiness").html(data);
		}
	});
	});
}
updatebusiness();



function updatesocial(){
	$("#submit").click(function(pro){
		event.preventDefault(pro);

		var site = $("#site").val();
		var link = $("#link").val();

	$.ajax({
		url : "code/update_sociallinks.php",
		method : "POST",
		dataType : "html",
		data 	 : {submit:1,site:site,link:link},
		success : function(data){
			$("#updatesocial").html(data);
		}
	});
	});
}
updatesocial();

// function purchase(){
// 	$.ajax({
// 		url : "code/fetch_purchase_pending.php",
// 		method : "GET",
// 		dataType : "text",
// 		success : function(data){
// 			$("#fetch_purchase").html(data);
// 			purchase();			
// 		}
// 	});
// 	}
// purchase();


// function copenver(){
// 	$("#copencode").keyup(function(){
// 		var copencode = $("#copencode").val();
// 		var lent = copencode.length;

// 		if(lent <= 0){
// 			$(".msg").html("");
// 		}else{


// 	$.ajax({
// 		url : "code/check_copen.php",
// 		method : "POST",
// 		dataType : "html",
// 		data 	 : {copen:copencode},
// 		success : function(data){
// 			$(".msg").html(data);			
// 		}
// 	});
// }

// 	});
// }
// copenver();



// function fetch_rrecent(){

// 	$.ajax({
// 		url : "code/fetch_recent_redumtions.php",
// 		method : "GET",
// 		dataType : "html",
// 		success : function(data2){
// 			$("#fetch_recent_redemtion").html(data2);	
// 			fetch_rrecent();
// 		}
// 	});
// 	}
// fetch_rrecent();


// function fetch_redu(){

// 	$.ajax({
// 		url : "code/fetch_redumtions.php",
// 		method : "GET",
// 		dataType : "html",
// 		success : function(data3){
// 			$("#fetch_redemtion").html(data3);	
// 			fetch_redu();
// 		}
// 	});
// 	}
// fetch_redu();


// function fetch_bcat(){

// 	$.ajax({
// 		url : "code/fetch_bcat.php",
// 		method : "GET",
// 		dataType : "html",
// 		success : function(data3){
// 			$("#fetch_bcat").html(data3);	
// 			fetch_bcat();
// 		}
// 	});
// 	}
// fetch_bcat();


// function payableamt(){
// 	$.ajax({
// 		url : "code/fetch_payable_amount.php",
// 		method : "GET",
// 		dataType : "text",
// 		success : function(data){
// 			payableamt();
// 			$("#fetch_payable").html(data);
			
// 		}
// 	});
// 	}
// payableamt();



// Login

function logins(){
$('#login').click(function(pro){
	event.preventDefault(pro);
	var uid = $("#uid").val();
	var password = $("#password").val();

$.ajax({
	url 	 : "code/login.php",
	method 	 : "POST",
	dataType : "text",
	data 	 : {login:1,uid:uid,password:password},
	success  : function(log){
		$("#showlogin").html(log);
	}
})
});
}
logins();

// // Update Cartqty

// function uqty(){
// $('#submit').click(function(e){
// 	event.preventDefault(e);

// 	var 	qty = $("#qty").val();
// 	var 	sps = $("#sps").val();

// $.ajax({
// 	url 	 : "code/update_cartqty.php",
// 	method 	 : "POST",
// 	dataType : "html",
// 	data 	 : {submit:1,qty:qty,sps:sps},
// 	success  : function(loges){
// 		$("#updateqty").html(loges);
// 	//	 window.open('mycart','_self');
// 	}
// })

// });
// }
// uqty();



// function add_bcat(){
// $('#submit').click(function(e){
// event.preventDefault(e);

// var catids = $(".catid").val();

// $.ajax({
// 	url 	 : "code/add_bcat.php",
// 	method 	 : "POST",
// 	dataType : "html",
// 	data 	 : {submit:1,catid:catid},
// 	success  : function(loges){
// 		$("#addcatid").html(loges);
// 	}
// })
// });
// }
// add_bcat();

// // uqty

// function signups(){
// $('#sigstar').click(function(e){
// 	event.preventDefault(e);
// 	var name = $("#name").val();
// 	var mobile = $("#mobile").val();
// 	var package = $("#package").val();
// 	var city = $("#city").val();
// 	var ref = $("#ref").val();
// 	var email = $("#email").val();

// $.ajax({
// 	url 	 : "code/register.php",
// 	method 	 : "POST",
// 	dataType : "html",
// 	data 	 : {submit:1,name:name,mobile:mobile,package:package,city:city,linkref:ref,email:email},
// 	success  : function(loge){
// 		$("#showregister").html(loge);
// 	}
// })
// });
// }
// signups();


// // CartCount

// function cartc(){
// 	$.ajax({
// 		url : "code/cartcount.php",
// 		method : "GET",
// 		dataType : "text",
// 		success : function(data){
// 			$("#thiscart").html(data);
// 			cartc();
// 		}
// 	});
// }
// cartc();


// // CartCount

// function deskcartc(){
// 	$.ajax({
// 		url : "code/cartcount.php",
// 		method : "GET",
// 		dataType : "text",
// 		success : function(datas){
// 			$("#maincartcount2").html(datas);
// 			deskcartc();
// 		}
// 	});
// }
// deskcartc();


// // MainCart Count
// function mcartc(){
// 	$.ajax({
// 		url : "code/fetch_cartcount.php",
// 		method : "GET",
// 		dataType : "text",
// 		success : function(data){
// 			$("#thecartcount").html(data);
// 		}
// 	});
// }
// mcartc();


// // FetchIndex

// function fetchindex(){
// 	$.ajax({
// 		url : "code/fetch_index.php",
// 		method : "GET",
// 		dataType : "html",
// 		success : function(data){
// 			$("#indexview").html(data);
// 		}
// 	});
// }
// fetchindex();



// // AddToCart

// function addtocart(){
// $('.addtocart a').click(function(s){
// 	event.preventDefault(s);

// var pid = $(this).attr('href').match(/pid=([0-9]+)/)[1]; 
// var viewid = $(this).attr('href').match(/viewid=([0-9]+)/)[1];
// $.ajax({
// 	url 	 : "code/add_tocart.php",
// 	method 	 : "GET",
// 	dataType : "html",
// 	data 	 : {viewid:viewid,pid:pid},
// 	success  : function(de){
// 		$("#showaddtocart").html(de);
// 		$(".error").fadeOut(2000);
// 		$(".success").fadeOut(2000);

// 	}
// })
// });
// }
// addtocart();







// // ForgetPassword
// function resetpassword(){
// $('#submit').click(function(prose){
// 	event.preventDefault(prose);
	
// 	var uid = $("#uid").val();

// $.ajax({
// 	url 	 : "code/reset_password.php",
// 	method 	 : "POST",
// 	dataType : "html",
// 	data 	 : {submit:1,uid:uid},
// 	success  : function(loges){
// 		$("#resetpassword").html(loges);
// 		$(".error").fadeOut(2000);
// 		$(".success").fadeOut(2000);
// 	}
// })
// });
// }
// resetpassword();


// // Conform Otp
// function conformotp(){
// $('#submit').click(function(prose){
// 	event.preventDefault(prose);
	
// 	var uid = $("#otp").val();

// $.ajax({
// 	url 	 : "code/conform_otp.php",
// 	method 	 : "POST",
// 	dataType : "html",
// 	data 	 : {submit:1,otp:uid},
// 	success  : function(logese){
// 		$("#conformotp").html(logese);
// 		$(".error").fadeOut(2000);
// 		$(".success").fadeOut(2000);
// 	}
// })
// });
// }
// conformotp();


// Update Password
function up(){
$('#uppass').click(function(pass){
	event.preventDefault(pass);
	var oldpass = $("#oldpass").val();
	var newpass = $("#newpass").val();

$.ajax({
	url 	 : "code/update_password.php",
	method 	 : "POST",
	dataType : "text",
	data 	 : {updatepassword:1, oldpass:oldpass,newpass:newpass},
	success  : function(sd){
		$("#passupdate").html(sd);
		$("#oldpass").val("");
		$("#newpass").val("");
		$(".error").fadeOut(2000);
		$(".success").fadeOut(2000);
	}
})
});
}
up();




// Update Prpfile
function upro(){
$('#update').click(function(pros){
	event.preventDefault(pros);
	var name = $("#name").val();
	var mobile = $("#mobile").val();
	var email = $("#email").val();

$.ajax({
	url 	 : "code/update_profile.php",
	method 	 : "POST",
	dataType : "text",
	data 	 : {update:1, email:email,name:name,mobile:mobile},
	success  : function(sd){
		$("#updatepro").html(sd);
		$(".error").fadeOut(2000);
		$(".success").fadeOut(2000);
		
	}
})


});
}
upro();


function signups(){
$('#submit').click(function(e){
	event.preventDefault(e);
	var name = $("#name").val();
	var mobile = $("#mobile").val();
	var package = $("#package").val();
	var email = $("#email").val();
	var cname = $("#cname").val();

$.ajax({
	url 	 : "code/add_merchant.php",
	method 	 : "POST",
	dataType : "html",
	data 	 : {submit:1,name:name,mobile:mobile,package:package,email:email,cname:cname},
	success  : function(loge){
		$("#showregister").html(loge);
	}
})
});
}
signups();




function updatemerchant(){
$('#submit').click(function(e){
	event.preventDefault(e);
	var name = $("#name").val();
	var mobile = $("#mobile").val();
	var email = $("#email").val();
	var status = $("#status").val();
	var gid = $("#gid").val();

$.ajax({
	url 	 : "code/update_merchant.php",
	method 	 : "POST",
	dataType : "html",
	data 	 : {submit:1,name:name,mobile:mobile,status:status,email:email,gid:gid},
	success  : function(loge){
		$("#updatemerchant").html(loge);
	}
})
});
}
updatemerchant();


});







