<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); ?>			

<div class="bodytouch">

<h3>Add New Category</h3>
<hr>
<p>Manage and Update your category.</p>
<br>

<div class="row">
<div class="col-md-6 col-md-offset-0">

<?php include("code/add_cat.php"); ?>

<form action="" method="POST" enctype="multipart/form-data">

<label>Category Title</label>	
<input type="text" id="cname" class="form-control" name='title' placeholder=" Category Title" required>


<label>Select Category Status</label>	 
<select class="form-control" name="statu" required>
	<option value="">Select Category Status</option>
	<option value="active">Active</option>
	<option value="inactive">InActive</option>
</select>

<button class="btn" type="submit" name="submit" >Add Category</button>

</form>
</div>
</div>
</div>






</div>

	</div>
</div>

</div>
</div>

</body>
</html>