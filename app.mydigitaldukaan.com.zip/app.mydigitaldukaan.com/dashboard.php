<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>



<?php include("files/sidemenu.php"); 
	include("code/getdetails.php");
?>
			
<div class="bodytouch">

<br>

<div class="row">
	<div class="col-md-4">
		<div class="inblocks">
			<!--<h5>Your Package Details</h5>-->
			<h3><?php echo $expire; ?></h3>
			<button class="btn">Your Package Details</button>
		</div>
	</div>
<?php include('code/dash_reach.php'); ?>	
<div class="col-md-4">
		<div class="inblocks">
			<!--<h5>Today Views</h5>-->
			<h3><?php echo $todayreach ?></h3>
			<button class="btn">Today Views</button>
		</div>
</div>

	<div class="col-md-4">
		<div class="inblocks">
			<!--<h5>Total Views</h5>-->
			<h3><?php echo $totalreach ?></h3>
			<button class="btn">Total Views</button>
		</div>
	</div>
	
</div>

<br>


</div>
	</div>
</div>

</div>
</div>

</body>
</html>