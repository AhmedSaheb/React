<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); 
?>			

<div class="bodytouch">

<h3>Update Business Logo</h3>
<hr>
<p>Manage and Update your profile settings here.</p>
<br>

<div class="row">
<div class="col-md-8 col-md-offset-0">

<div id="showregister"></div>
<?php include("code/update_logo.php"); ?>
<?php include("code/view_logo.php"); ?>


	<h3>Business Logo</h3>
	<h5>Update Manage your Business logo.</h5>
	<hr>
	<form action="" method="POST" enctype="multipart/form-data">
	
	<label>Upload Logo Size Must be in Format 120x120</label>
	<input type="file" name="file" class="form-control">
	<input type="hidden" name="glogo" value="<?php echo $glogo ?>">
	<input type="hidden" name="logoid" value="<?php echo $logoid ?>">
	<button class="btn" type="update" name="update">Update Logo</button>

	</form>




<div class="dlogo" style="padding: 30px;">
	<h4>Active Logo</h4>
	<hr>
	<img src="../smartdigitalvcard.com/images/company_logo/<?php echo $glogo; ?>" style='height: 80px;'>
</div>
</div>
</div>






</div>

	</div>
</div>

</div>
</div>

</body>
</html>