<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); 
?>			


<?php 
	

if(isset($_GET['r'])){
		$r= $_GET['r'];
include("code/connect.php");
include("code/getdetails.php");

	$del = "delete from vc_gallery where bcode='$umcode' && id='$r'";
	$ssp = mysqli_query($con,$del);
	if(mysqli_query($con,$del)){
		echo "<div class='success'>Gallery Removed Succssfully !</div>";
	}else{
		echo "<div class='success'>Gallery Removed Error !</div>";
	}

	}
?>
<div class="bodytouch">

<h3>Add Gallery</h3>
<h5>Adding Images and create gallery for your template.</h5>
<hr>

	<?php include("code/add_gallery.php"); ?>

<div class="row">
	<div class="col-md-6 col-md-offset-0">

	<form action="" method="POST" enctype="multipart/form-data">
	<label>Name</label>
	<input type="text" class="form-control" placeholder="Image Title" name="title" id="title">
	<label>Image</label>
	
	<input type="file" class="form-control" placeholder="file" name="file" id="file">
	<button class="btn" type="submit" name="submit">Upload</button>

</form>
</div>
</div>
<br>


<h4>Gallery</h4>
<hr>
<div class="table table-responsive">
	<table class="table table-bordered">
		<tr>
			<th>SNO</th>
			<th>Title</th>
			<th>Images</th>
			<th>Action</th>
		</tr>

<?php 
	
	include("code/connect.php");
	include("code/getdetails.php");
	$sno = 0;
	$f = "select * from vc_gallery where bcode='$umcode'";
	$lo = mysqli_query($con,$f);
	while ($nn = mysqli_fetch_array($lo)){
		$sid = $nn['id'];
		$title = $nn['title'];
		$file = $nn['file'];
		$status = $nn['status'];
	$sno = $sno+1;
	
echo "
	<tr>
			<td>$sno</td>
			<td>$title</td>
			<td><img src='http://smartdigitalvcard.com/images/gallery/$file' style='height:40px;'></td>
			<td><a href='update-gallery?r=$sid'>Remove</a></td>
		</tr>
";

	}

?>
		
	</table>
</div>
</div>

</div>

</body>
</html>