<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>



<?php include("files/sidemenu.php"); ?>
			

<div class="bodytouch">

<h3>Manage Business</h3>
<hr>



<?php 

include("mcode/connect.php");
include("mcode/getdetails.php");

if($pacs=="free"){
    
?>

    <div class="block">
<a href="update-logo">
<img src="images/logoupdate.png">
<h4>Update Logo</h4>
</a>
</div>


<div class="block">
<a href="update-business">
<img src="images/business.png">
<h4>Update Business</h4>
</a>
</div>

<div class="block">
<a href="update-sociallinks">
<img src="images/sociallinks.png">
<h4>Add Social Links</h4>
</a>
</div>

<?php 


}else{

?>

<div class="block">
<a href="update-logo">
<img src="images/logoupdate.png">
<h4>Update Logo</h4>
</a>
</div>


<div class="block">
<a href="update-business">
<img src="images/business.png">
<h4>Update Business</h4>
</a>
</div>

<div class="block">
<a href="update-services">
<img src="images/services.png">
<h4>Service & Products</h4>
</a>
</div>


<div class="block">
<a href="update-sociallinks">
<img src="images/sociallinks.png">
<h4>Add Social Links</h4>
</a>
</div>

<div class="block">
<a href="update-videos">
<img src="images/videos.png">
<h4>Upload Videos</h4>
</a>
</div>

<div class="block">
<a href="add_cat.php">
<img src="images/add_icon.ico">
<h4>Add Category</h4>
</a>
</div>


<div class="block">
<a href="update-gallery">
<img src="images/gallery.png">
<h4>Add Images</h4>
</a>
</div>


<div class="block">
<a href="update-list">
<img src="images/serviceslist.png">
<h4>Add Service List</h4>
</a>
</div>

<!--<div class="block">-->
<!--<a href="add_offers.php">-->
<!--<img src="images/offers.png">-->
<!--<h4>Add Offers</h4>-->
<!--</a>-->
<!--</div>-->


<!--<div class="block">-->
<!--<a href="update-downloads">-->
<!--<img src="images/downloads.png">-->
<!--<h4>Upload Files</h4>-->
<!--</a>-->
<!--</div>-->


<?php } ?>



</div>

</body>
</html>