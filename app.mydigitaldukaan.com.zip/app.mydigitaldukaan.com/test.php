<?php
include "phpqrcode/qrlib.php";

$path = "qrcode/";
$file = $path.uniqid().".png";

$text = "https://www.google.com";

QRcode::png($text,$file,'XL');

echo "<img src='".$file."'>";

?>