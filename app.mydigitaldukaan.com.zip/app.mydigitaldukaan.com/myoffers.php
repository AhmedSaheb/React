<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); 
?>			


<?php 
	

if(isset($_GET['r'])){
		$r= $_GET['r'];
include("code/connect.php");
include("code/getdetails.php");

	$del = "delete from vc_services where bcode='$umcode' && id='$r'";
	$ssp = mysqli_query($con,$del);
	if(mysqli_query($con,$del)){
		echo "<div class='success'>Product Removed Succssfully !</div>";
	}else{
		echo "<div class='success'>Product Removed Error !</div>";
	}

	}
?>
<div class="bodytouch">


<div class="row">
    <div class='col-md-6'>
<h4 style="margin-top:15px;">My Offers</h4>        
    </div>
    <div class='col-md-6'>
<button class='btn' style='position:relative; float:right; right:20px; margin-top:0px;'>+Create Offer</button>
    </div>
</div>


<div class='clearfix'></div>
<hr>
<div class="table table-responsive">
	<table class="table table-bordered">
		<tr>
			<th>SNO</th>
			<th>Offer Id</th>
			<th>Title</th>
			<th>Product Price</th>
            <th>Discount</th>
            <th>Selling Price</th>
			<th>Start Date</th>
			<th>End Date</th>
			<th>Offer Image</th>
			<th>Status</th>
			<th>Image</th>
			<th>Action</th>
		</tr>

<?php 
	
	include("code/connect.php");
	include("code/getdetails.php");
	$sno = 0;
	$f = "select * from vc_services where bcode='$umcode'";
	$lo = mysqli_query($con,$f);
	while ($nn = mysqli_fetch_array($lo)){
		$sid = $nn['id'];
		$title = $nn['title'];
		$image = $nn['image'];
		$price = $nn['price'];
		$button = $nn['button'];
		$status = $nn['status'];
    	$sno = $sno+1;
	
echo "
	<tr>
			<td>$sno</td>
			<td>$title</td>
			<td>$price</td>
			<td>$button</td>
			<td><img src='http://smartdigitalvcard.com/images/company_service/$image' style='height: 30px'></td>
			<td><a href='update-services?r=$sid'>Remove</a> | <a href='edit-services?r=$sid'>Update</a></td>
		</tr>
";

	}

?>



		
	</table>
</div>
</div>

</div>

</body>
</html>