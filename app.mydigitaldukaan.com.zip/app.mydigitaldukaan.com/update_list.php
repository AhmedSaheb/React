<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); 
?>			


<?php include("code/remove_list.php"); ?>
<div class="bodytouch">

<h3>Add Service/Products List</h3>
<h5>Adding Services List will help your customer understand about your services.</h5>
<hr>

<!--<?php include("code/add_list.php"); ?>-->

<div id="add_list"></div>

<div class="row">
	<div class="col-md-6 col-md-offset-0">
	<form action="" method="POST" enctype="multipart/form-data">
	<label>Service / Products Name</label>
	<input type="text" class="form-control" placeholder="Title" name="title" id="title">
		<button class="btn" type="submit" id="submit" name="submit">Submit</button>

</form>
</div>
</div>
<br>

<h4>Products & Services</h4>
<hr>
<div class="table table-responsive">
	
<!-- <div id="showvideos"></div> -->
<?php include("code/fetch_list.php"); ?>		
	</table>
</div>
</div>

</div>

</body>
</html>