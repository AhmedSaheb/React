<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); 
?>			


<?php 
	

if(isset($_GET['r'])){
		$r= $_GET['r'];
include("code/connect.php");
include("code/getdetails.php");

	$del = "delete from vc_services where bcode='$umcode' && id='$r'";
	$ssp = mysqli_query($con,$del);
	if(mysqli_query($con,$del)){
		echo "<div class='success'>Product Removed Succssfully !</div>";
	}else{
		echo "<div class='success'>Product Removed Error !</div>";
	}

	}
?>
<div class="bodytouch">

<h3>Add New Services</h3>
	<h5>Adding Services will help your customer engage and know about your services.</h5>
	<hr>



	<?php include("code/add_services.php"); ?>

<div class="row">
	<div class="col-md-6 col-md-offset-0">
    

	<form action="" method="POST" enctype="multipart/form-data">
	
	<label>Select Category</label>
	<select class='form-control' name='cat'>
	    <option value=''>Select Category</option>
	    <option value='all'>All</option>
	
	<?php 
	    include("code/connect.php");
	    include("code/getdetails.php");
	    
	    $ss = "select * from bus_cat where bcode='$umcode'";
	    $ls = mysqli_query($con,$ss);
	    while($lol = mysqli_fetch_array($ls)){
	        $ccid = $lol['id'];
	        $cctitle = $lol['title'];
	?>
	    <option value='<?php echo $ccid ?>'><?php echo $cctitle ?></option>
	<?php } ?>
	
	</select>
	
	<label>Title</label>
	<input type="text" class="form-control" placeholder="Title" name="title" id="title">
	<label>Price</label>
	<input type="text" class="form-control" placeholder="Price" name="price" id="Price">
	
	<label>Button Type</label>
	<select class='form-control' name='button'>
	    <option value=''>Select Button Type</option>
	    <option value='Book Now'>Book Now</option>
	    <option value='Order Now'>Order Now</option>
	    <option value='Enquery'>Enquery</option>
	</select>
	
	<label>Offer Type</label>
	<select class='form-control' name='offertype'>
	    <option value=''>Select Offer Type</option>
	    <option value='normal'>Normal</option>
	    <option value='offer'>Offer</option>
	</select>
	
	<label>Service Image</label>
	<input type="file" class="form-control" placeholder="Title" name="file" id="file">
	<label>Discription</label>
	<textarea class="form-control" style="height:150px;" name="disc" placeholder="Discription of your Products / Service"></textarea>
	<button class="btn" type="submit" name="submit">Submit</button>
</form>
</div>
</div>
<br>


<h4>Products & Services</h4>
<hr>
<div class="table table-responsive">
	<table class="table table-bordered">
		<tr>
			<th>SNO</th>
			<th>Title</th>
			<th>Price</th>
			<th>Button Type</th>
			<th>Image</th>
			<th>Action</th>
		</tr>

<?php 
	
	include("code/connect.php");
	include("code/getdetails.php");
	$sno = 0;
	$f = "select * from vc_services where bcode='$umcode'";
	$lo = mysqli_query($con,$f);
	while ($nn = mysqli_fetch_array($lo)){
		$sid = $nn['id'];
		$title = $nn['title'];
		$image = $nn['image'];
		$price = $nn['price'];
		$button = $nn['button'];
		$status = $nn['status'];
    	$sno = $sno+1;
	
echo "
	<tr>
			<td>$sno</td>
			<td>$title</td>
			<td>$price</td>
			<td>$button</td>
			<td><img src='http://smartdigitalvcard.com/images/company_service/$image' style='height: 30px'></td>
			<td><a href='update-services?r=$sid'>Remove</a> | <a href='edit-services?r=$sid'>Update</a></td>
		</tr>
";

	}

?>



		
	</table>
</div>
</div>

</div>

</body>
</html>