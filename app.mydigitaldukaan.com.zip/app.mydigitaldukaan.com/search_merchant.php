<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
			

<div class="bodytouch">

<h3>Manage Products</h3>
<hr>

<div class="row">
	<div class="col-md-4">
		<form action="search-merchant" method="GET"> 
		<input type="text" style="margin-top: 5px; padding: 15px; box-shadow: none;" placeholder="Search..." class="form-control" name="keyword">
		<input type="submit" name="search" class="hidden">
		</form>
	</div>
	<div class="col-md-8 text-right">
		<button class="btn" onClick='window.open("add-merchant","_self");'>+ Add New Merchant</button>
	</div>

</div>

<!-- Table -->
<br>
<div class="table table-hover table-responsive">
	<table class="table table-bordered">
	<tr>
		<th>SNO</th>
		<th>Company Name</th>
		<th>Date</th>
		<th>Name</th>
		<th>Email</th>
		<th>Mobile</th>
		<th>Package</th>
		<th>Status</th>
		<th>Package Status</th>
		<th>Expire In</th>
		<th>Action</th>
	</tr>

	<?php include("code/search_merchant.php"); ?>

	</table>
</div>





</div>

	</div>
</div>

</div>
</div>

</body>
</html>