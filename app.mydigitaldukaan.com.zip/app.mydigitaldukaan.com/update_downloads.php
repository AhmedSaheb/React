<?php include("code/session.php"); ?>
<?php include('files/header.php'); ?>


<?php include("files/sidemenu.php"); ?>
<?php include("code/getdetails.php"); 
?>			


<?php 
	

if(isset($_GET['r'])){
		$r= $_GET['r'];
include("code/connect.php");
include("code/getdetails.php");

	$del = "delete from vc_downloads where bcode='$umcode' && id='$r'";
	$ssp = mysqli_query($con,$del);
	if(mysqli_query($con,$del)){
		echo "<div class='success'>File Removed Succssfully !</div>";
	}else{
		echo "<div class='success'>Product Removed Error !</div>";
	}

	}
?>
<div class="bodytouch">

<h3>Add New Files</h3>
	<h5>Adding Services will help your customer engage more to your page.</h5>
	<hr>



	<?php include("code/add_downloads.php"); ?>

<div class="row">
	<div class="col-md-6 col-md-offset-0">

	<form action="" method="POST" enctype="multipart/form-data">
	<label>Title</label>
	<input type="text" class="form-control" placeholder="Title" name="title" id="title">
	<label>File</label>
	<input type="file" class="form-control" placeholder="File" name="file" id="file">
	<button class="btn" type="submit" name="submit">Submit</button>
</form>
</div>
</div>
<br>


<h4>Files</h4>
<hr>
<div class="table table-responsive">
	<table class="table table-bordered">
		<tr>
			<th>SNO</th>
			<th>Title</th>
			<th>Action</th>
		</tr>

<?php 
	
	include("code/connect.php");
	include("code/getdetails.php");
	$sno = 0;
	$f = "select * from vc_downloads where bcode='$umcode'";
	$lo = mysqli_query($con,$f);
	while ($nn = mysqli_fetch_array($lo)){
		$sid = $nn['id'];
		$title = $nn['title'];
		$file = $nn['file'];
		$status = $nn['status'];
		$sno = $sno+1;
	
echo "
	<tr>
			<td>$sno</td>
			<td>$title</td>
			<td><a href='../smartdigitalvcard.com/images/downloads/$file'>Download File</a> | <a href='update-downloads?r=$sid'>Remove</a></td>
		</tr>
";

	}

?>



		
	</table>
</div>
</div>

</div>

</body>
</html>